# Excel → PDF Converter (WPF + Excel COM)

**Date:** 2026-10-07  
**Status:** Approved design (implemented)  
**Note:** Conversion path superseded by `2026-10-08-custom-paper-size-design.md` (temp copy + always apply UI paper size).

## Goal

Build a small WPF desktop utility that converts an Excel workbook to PDF using Microsoft Excel’s COM automation. Default export matches Excel print preview (WYSIWYG). An optional mode fits **each worksheet onto one PDF page**.

## Requirements

| Item | Decision |
|------|----------|
| Form factor | Desktop tool: pick Excel → options → export |
| Sheets | One PDF for the workbook: all **visible** worksheets (and visible chart sheets). Hidden / very-hidden sheets are not exported. |
| WYSIWYG (default / option OFF) | Export with existing Excel `PageSetup` / print settings unchanged, including print areas |
| Fit option ON | **One visible worksheet → one PDF page**: temporarily set `Zoom = false`, `FitToPagesWide = 1`, `FitToPagesTall = 1`, and export with `IgnorePrintAreas = true` so the **entire used sheet** (not a print-area subset) is scaled onto one page |
| Output path | Same directory as source, same base name, `.pdf` extension |
| Overwrite | If target PDF exists, confirm before overwriting |
| Source file | Must not be modified (restore any temporary `PageSetup` changes; close without saving) |

### Out of scope (YAGNI)

- Batch conversion queue
- Per-worksheet selection UI
- Custom paper size / margins UI
- CLI / library API for other apps
- Non-Excel engines (OpenXML-only, LibreOffice, etc.)
- Scaling each existing print-preview page independently (that is **not** this feature)

### Sheet types and protected files

- **Visible worksheets:** included; with fit ON, each becomes one PDF page.
- **Hidden / very-hidden worksheets and hidden / very-hidden chart sheets:** not exported; do not unhide.
- **Visible chart sheets:** included using Excel’s default chart-sheet print behavior; do not apply worksheet `PageSetup` fit.
- **Password-protected workbooks:** fail with a short message (no password UI).
- **Zero visible sheets:** fail with a short message (nothing to export).

## Prerequisites

- Windows
- Desktop Microsoft Excel installed (COM / Interop)
- Project: existing WPF app targeting `net10.0-windows`

## Architecture

Three units with clear boundaries:

1. **UI — `MainWindow`**  
   File picker, fit-option checkbox, derived output path display, convert button, status text, overwrite confirmation. Does not create Excel COM objects on the UI thread.

2. **Service — `ExcelToPdfConverter`**  
   Owns Excel COM lifecycle and export. Single entry: convert given options; always cleans up in `finally`. All Excel COM calls run on a **dedicated STA thread created per conversion** (Excel Interop is STA). Do not reuse the thread across conversions. The UI awaits that work so the window stays responsive. v1 has **no cancel control**.

3. **Model — `ConversionOptions`**  
   `InputPath`, `OutputPath`, `FitSheetToOnePdfPage`.

```
MainWindow → ConversionOptions → ExcelToPdfConverter (STA) → Excel COM → PDF file
```

## UI

- Title: Excel → PDF
- Excel path: text box + Browse (filter `.xlsx`, `.xls`, `.xlsm`)
- Output path: read-only, auto-filled as `{directory}\{name}.pdf`
- Checkbox: “每个工作表缩放到一张 PDF 页” → `FitSheetToOnePdfPage`
- Convert button: disabled while running; status: idle / running / success (path) / failure (short message)

## Conversion flow

1. User selects Excel file; UI sets output path.
2. User clicks Convert; if PDF exists, confirm overwrite; cancel aborts.
3. UI calls `ExcelToPdfConverter.ConvertAsync(options)` (no cancellation in v1).
4. Converter (new STA thread per conversion):
   - Start Excel (`Visible = false`, `DisplayAlerts = false`)
   - Open workbook read-only (`ReadOnly = true`)
   - If fit option: for each **visible worksheet**, backup `Zoom`, `FitToPagesWide`, `FitToPagesTall`; set `Zoom = false`, `FitToPagesWide = 1`, `FitToPagesTall = 1`
   - `ExportAsFixedFormat(xlTypePDF, Filename, …)` for the workbook
     - Fit OFF: `IgnorePrintAreas = false` (honor print areas; WYSIWYG)
     - Fit ON: `IgnorePrintAreas = true` (whole sheet on one page)
     - Always: `OpenAfterPublish = false`
   - In `finally`: restore worksheet `PageSetup` where changed → close workbook **without saving** → quit Excel → release COM
5. UI shows success or error.

## Error handling

| Case | Behavior |
|------|----------|
| Excel not installed / COM create fails | Message: install desktop Microsoft Excel |
| Missing / locked source | Message: invalid path or file in use |
| Password-protected workbook | Message: file is password-protected; cannot open |
| Zero visible sheets | Message: no visible sheets to export |
| Export failure | Short error; Excel process still cleaned up |
| Target PDF locked | Message: close the program using the PDF and retry |
| Double-click convert | Button disabled; no concurrent runs |
| Any exception | `try/finally` restores setup, closes workbook, quits Excel, releases COM |

## File layout

```
ExcelToPdf/
  MainWindow.xaml
  MainWindow.xaml.cs
  Models/ConversionOptions.cs
  Services/ExcelToPdfConverter.cs
  ExcelToPdf.csproj  (+ Microsoft.Office.Interop.Excel)
```

## Testing (manual)

1. Multi-sheet workbook → one PDF; sheet order matches workbook tab order (visible sheets).
2. Fit OFF → pagination/scale match Excel print preview, including print areas (WYSIWYG).
3. Fit ON → **each visible worksheet occupies one PDF page** (entire used range scaled to fit, print area ignored).
4. Hidden sheets do not appear in the PDF.
5. Existing / locked PDF → overwrite confirmation or lock error.
6. Password-protected file → error message; Excel cleaned up.
7. UI stays responsive; no leftover `EXCEL.EXE` after success or failure.
8. Source workbook unchanged (content / last-write time).

## Interfaces (contracts)

```csharp
public sealed class ConversionOptions
{
    public required string InputPath { get; init; }
    public required string OutputPath { get; init; }
    public bool FitSheetToOnePdfPage { get; init; }
}

public sealed class ExcelToPdfConverter
{
    // Throws InvalidOperationException / COMException / IOException
    // with user-actionable messages where possible.
    public Task ConvertAsync(ConversionOptions options);
}
```

v1 does not accept a `CancellationToken` and the UI has no Cancel button. The convert button stays disabled until conversion finishes (success or failure).
