# Custom PDF Paper Size (Excel → PDF)

**Date:** 2026-10-08  
**Status:** Approved design (pending implementation plan)  
**Extends / supersedes conversion path in:** `2026-10-07-excel-to-pdf-design.md`

## Goal

Let the user choose PDF paper size: common presets with orientation, or custom width/height in **pixels** with a selectable **DPI** (default 96). All Excel mutations happen on a **temporary copy**; the source workbook is never opened and never modified.

## Supersedes base conversion steps

Once this feature ships, **every** conversion uses:

1. Copy source → temp  
2. Open **temp only** (not read-only; allow PageSetup changes on the copy)  
3. Apply paper (and optional fit) on the copy  
4. Export PDF  
5. Close without saving → quit Excel → delete temp  

What stays from the base spec: STA thread per conversion, visible-sheet export rules, Fit ON/OFF semantics, overwrite confirm, error messages for Excel/password/lock, `OpenAfterPublish = false`, no cancel in v1.

**Product change vs original WYSIWYG:** Fit OFF still honors print areas and pagination *relative to the selected paper*, but **no longer keeps the workbook’s original paper size**. v1 always applies the UI paper setting (default A4 portrait). There is no “use Excel’s paper size” mode.

## Requirements

| Item | Decision |
|------|----------|
| Presets | A4, A3, A5, Letter, Legal |
| Orientation | Portrait / Landscape for presets |
| Custom | Width (px), height (px), DPI (default 96) |
| Default | A4, Portrait |
| Custom + orientation | Orientation control **disabled**; width/height are final page size |
| Conversion | `inches = pixels / Dpi`; apply via Excel `PageSetup` on temp copy |
| Source file | Never opened; only `File.Copy` |
| Fit option | Unchanged when ON |

### Out of scope (YAGNI)

- Custom margins  
- Persist last paper choice  
- “Use Excel’s paper size” mode  
- Post-export PDF libraries  

## Preset → Excel mapping

| Preset | `XlPaperSize` |
|--------|----------------|
| A4 | `xlPaperA4` |
| A3 | `xlPaperA3` |
| A5 | `xlPaperA5` |
| Letter | `xlPaperLetter` |
| Legal | `xlPaperLegal` |

Orientation: `Landscape == true` → `xlLandscape`, else `xlPortrait`.

## Preset paper COM sequence

For each visible **worksheet** when mode is Preset:

1. `PageSetup.PaperSize =` mapped `XlPaperSize`  
2. `PageSetup.Orientation = xlLandscape` or `xlPortrait`  

Do not set `PageWidth` / `PageHeight` for presets.

## Custom paper COM sequence

For each visible **worksheet** when mode is Custom:

1. `PageSetup.PaperSize = xlPaperUser` (256)  
2. `PageSetup.Orientation = xlPortrait` (fixed; UI width/height define the physical page)  
3. `PageSetup.PageWidth = widthInches`  
4. `PageSetup.PageHeight = heightInches`  

`widthInches = WidthPx / Dpi`, `heightInches = HeightPx / Dpi`.  
`ToInches` is **custom-only**; callers must not use it for preset mode (throw `InvalidOperationException` if Mode ≠ Custom).

## Chart sheets

- **Visible chart sheets:** still included in workbook export (base behavior).  
- **Paper override:** applied only to **visible worksheets**. Chart sheets keep Excel’s default chart print paper (mixed page sizes in one PDF are acceptable in v1).  
- **Hidden / very-hidden** worksheets and chart sheets: not exported.

## Architecture

| Unit | Responsibility |
|------|----------------|
| `Models/PaperSizeSettings.cs` | Preset vs custom, orientation, px, DPI |
| `Services/PaperSizeHelper.cs` | Validate; px→inches; map preset → Excel enums (values returned as data the converter applies) |
| `Models/ConversionOptions.cs` | Add `Paper` (default A4 portrait) |
| `Services/ExcelToPdfConverter.cs` | Temp copy lifecycle + apply paper + fit + export |
| `MainWindow` | Paper UI + validation before convert |

```
MainWindow → ConversionOptions(+Paper) → copy to temp → Excel COM on copy → PDF
                                              ↓
                                         delete temp
```

## UI

- Combo: A4 / A3 / A5 / Letter / Legal / 自定义 (default A4)  
- Orientation: 纵向 / 横向 (presets only; default 纵向)  
- Custom: Width (px), Height (px), DPI (default 96)  
- Fit checkbox unchanged  

## Validation (`PaperSizeHelper.TryValidate`)

Returns `bool` + `out string errorMessage` (no throw for validation):

- Width, height, DPI must be **> 0** (model uses `double`; UI may parse from text)  
- For custom: each side inches in **[0.1, 22]**  
- Preset mode: skip px/DPI checks  

UI calls this before starting conversion. Converter may call again as a guard.

## Conversion flow (detail)

1. UI validates paper settings.  
2. Overwrite confirm if PDF exists.  
3. STA:  
   - Copy `InputPath` → `%TEMP%\ExcelToPdf\{guid}{originalExtension}`  
   - Open **temp** with empty passwords; **not** read-only  
   - Ensure at least one visible sheet  
   - Apply paper to each **visible worksheet** (preset or custom sequence above)  
   - If fit: FitToPages 1×1 on those worksheets; `IgnorePrintAreas = true` on export  
   - Else: `IgnorePrintAreas = false`  
   - `ExportAsFixedFormat` → `OutputPath`, `OpenAfterPublish = false`  
   - `finally`: close workbook **without saving** → quit → release COM → delete temp (best-effort; failed delete does not fail a successful export)

## Error handling

| Case | Behavior |
|------|----------|
| Copy fails | 无法创建临时副本 |
| Invalid custom / out of range | UI message; do not start Excel |
| Temp delete fails | Success still shown; optional short note |
| Other | Same as base converter |

## Testing

**Unit (`PaperSizeHelper`):** px/DPI → inches; invalid returns false + message; preset enum mapping values.

**Manual:**
1. Default A4 portrait.  
2. Letter landscape.  
3. Custom ≈ A4: 794×1123 @ 96 DPI.  
4. Fit OFF with non-default paper (confirms override vs old Excel paper).  
5. Source last-write unchanged; no leftover temp under `%TEMP%\ExcelToPdf`.  
6. Workbook with visible chart sheet still exports (mixed paper OK).  
7. Fit ON/OFF with paper override.

## Interfaces

```csharp
public enum PaperPreset { A4, A3, A5, Letter, Legal }

public enum PaperMode { Preset, Custom }

public sealed class PaperSizeSettings
{
    public PaperMode Mode { get; init; } = PaperMode.Preset;
    public PaperPreset Preset { get; init; } = PaperPreset.A4;
    public bool Landscape { get; init; }
    public double WidthPx { get; init; }
    public double HeightPx { get; init; }
    public double Dpi { get; init; } = 96;
}

public sealed class ConversionOptions
{
    public required string InputPath { get; init; }
    public required string OutputPath { get; init; }
    public bool FitSheetToOnePdfPage { get; init; }
    public PaperSizeSettings Paper { get; init; } = new();
}

public static class PaperSizeHelper
{
    public static bool TryValidate(PaperSizeSettings paper, out string errorMessage);
    public static (double WidthInches, double HeightInches) ToInches(PaperSizeSettings paper);
}
```
