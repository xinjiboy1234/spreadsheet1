# Custom PDF Paper Size Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add preset/custom paper size (px + DPI) and always convert via a temp copy of the Excel file.

**Architecture:** `PaperSizeSettings` + `PaperSizeHelper` for validation/conversion; converter copies source to `%TEMP%\ExcelToPdf`, opens the copy, applies paper (and optional fit), exports PDF, deletes temp. UI adds preset/orientation/custom fields.

**Tech Stack:** WPF, Excel Interop, xUnit  
**Spec:** `docs/superpowers/specs/2026-10-08-custom-paper-size-design.md`  
Skip git commits if no `.git`.

---

## Chunk 1: Models + PaperSizeHelper + tests

### Task 1: PaperSizeSettings + PaperSizeHelper (TDD)

**Files:**
- Create: `ExcelToPdf/Models/PaperSizeSettings.cs`
- Create: `ExcelToPdf/Services/PaperSizeHelper.cs`
- Create: `ExcelToPdf.Tests/PaperSizeHelperTests.cs`
- Modify: `ExcelToPdf/Models/ConversionOptions.cs`

- [x] Add enums + `PaperSizeSettings` + `Paper` on `ConversionOptions`
- [x] Failing tests for `TryValidate`, `ToInches`, preset mode rejects `ToInches`
- [x] Implement helper (0.1–22 inches, DPI/px > 0)
- [x] `dotnet test` PASS
- [x] Skip commit if no git

## Chunk 2: Converter temp copy + paper apply

### Task 2: ExcelToPdfConverter

**Files:**
- Modify: `ExcelToPdf/Services/ExcelToPdfConverter.cs`

- [x] Copy to temp; open copy not read-only; delete temp in finally
- [x] Apply paper to visible worksheets (preset / custom COM sequence)
- [x] Fit: apply on copy without restore-to-source (temp is discarded); release worksheet COM after fit
- [x] Build succeeds

## Chunk 3: UI

### Task 3: MainWindow paper controls

**Files:**
- Modify: `ExcelToPdf/MainWindow.xaml`
- Modify: `ExcelToPdf/MainWindow.xaml.cs`

- [x] Combo presets + 自定义; orientation; width/height/DPI
- [x] Enable/disable custom fields; validate before convert
- [x] Pass `Paper` into `ConversionOptions`
- [x] Build + test PASS
