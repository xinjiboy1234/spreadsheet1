# Excel → PDF Converter Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship a WPF desktop tool that converts an Excel workbook to PDF via Excel COM, with an option to fit each visible worksheet onto one PDF page.

**Architecture:** `MainWindow` collects the file and checkbox, derives the output path, and awaits `ExcelToPdfConverter.ConvertAsync`. The converter runs all Excel Interop on a **new STA thread per conversion**, temporarily adjusts worksheet `PageSetup` when fitting, exports the workbook, then always restores setup, closes without saving, quits Excel, and releases COM.

**Tech Stack:** WPF, `net10.0-windows`, `Microsoft.Office.Interop.Excel`, xUnit for non-COM helpers. Real Excel COM is verified manually (spec).

**Spec:** `docs/superpowers/specs/2026-10-07-excel-to-pdf-design.md`

This folder may not be a git repository. **Skip every Commit step if `.git` is missing.** Do not run `git init` unless the user asks.

---

## File structure

| File | Responsibility |
|------|----------------|
| `ExcelToPdf/Models/ConversionOptions.cs` | Conversion parameters |
| `ExcelToPdf/Services/PdfOutputPath.cs` | Same-directory `.pdf` path from Excel path |
| `ExcelToPdf/Services/StaRunner.cs` | Run an action on a dedicated STA thread |
| `ExcelToPdf/Services/ComRelease.cs` | Safe `Marshal.ReleaseComObject` |
| `ExcelToPdf/Services/ExcelToPdfConverter.cs` | Excel COM open / fit / export / cleanup |
| `ExcelToPdf/MainWindow.xaml` + `.cs` | UI only; no Excel COM |
| `ExcelToPdf/ExcelToPdf.csproj` | Interop package |
| `ExcelToPdf.Tests/PdfOutputPathTests.cs` | Path helper tests |
| `ExcelToPdf.slnx` | Include test project |

---

## Chunk 1: Options, path helper, STA/COM utilities, tests

### Task 1: PdfOutputPath + tests

**Files:**
- Create: `ExcelToPdf.Tests/ExcelToPdf.Tests.csproj`
- Create: `ExcelToPdf.Tests/PdfOutputPathTests.cs`
- Create: `ExcelToPdf/Services/PdfOutputPath.cs`
- Modify: `ExcelToPdf.slnx`

- [x] **Step 1: Add test project and failing tests**

Create `ExcelToPdf.Tests/ExcelToPdf.Tests.csproj`:

```xml
<Project Sdk="Microsoft.NET.Sdk">
  <PropertyGroup>
    <TargetFramework>net10.0-windows</TargetFramework>
    <ImplicitUsings>enable</ImplicitUsings>
    <Nullable>enable</Nullable>
    <IsPackable>false</IsPackable>
  </PropertyGroup>
  <ItemGroup>
    <PackageReference Include="Microsoft.NET.Test.Sdk" Version="17.14.1" />
    <PackageReference Include="xunit" Version="2.9.3" />
    <PackageReference Include="xunit.runner.visualstudio" Version="3.1.4" />
  </ItemGroup>
  <ItemGroup>
    <ProjectReference Include="..\ExcelToPdf\ExcelToPdf.csproj" />
  </ItemGroup>
</Project>
```

Replace `ExcelToPdf.slnx` with:

```xml
<Solution>
  <Project Path="ExcelToPdf/ExcelToPdf.csproj" />
  <Project Path="ExcelToPdf.Tests/ExcelToPdf.Tests.csproj" />
</Solution>
```

Create `ExcelToPdf.Tests/PdfOutputPathTests.cs`:

```csharp
using ExcelToPdf.Services;
using Xunit;

namespace ExcelToPdf.Tests;

public class PdfOutputPathTests
{
    [Fact]
    public void FromExcelPath_replaces_extension_with_pdf_same_directory()
    {
        var excel = @"D:\files\report.xlsx";
        var pdf = PdfOutputPath.FromExcelPath(excel);
        Assert.Equal(@"D:\files\report.pdf", pdf);
    }

    [Fact]
    public void FromExcelPath_handles_xlsm_and_xls()
    {
        Assert.EndsWith("a.pdf", PdfOutputPath.FromExcelPath(@"C:\t\a.xlsm"));
        Assert.EndsWith("b.pdf", PdfOutputPath.FromExcelPath(@"C:\t\b.xls"));
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("   ")]
    public void FromExcelPath_rejects_blank(string? path)
    {
        Assert.Throws<ArgumentException>(() => PdfOutputPath.FromExcelPath(path!));
    }
}
```

Do **not** create `PdfOutputPath.cs` yet.

- [x] **Step 2: Run tests — expect fail**

Run:

```powershell
dotnet test "D:\files\projects\netcore\wpf\ExcelToPdf\ExcelToPdf\ExcelToPdf.Tests\ExcelToPdf.Tests.csproj"
```

Expected: FAIL / compile error: `PdfOutputPath` does not exist.

- [x] **Step 3: Implement PdfOutputPath**

Create `ExcelToPdf/Services/PdfOutputPath.cs`:

```csharp
namespace ExcelToPdf.Services;

public static class PdfOutputPath
{
    public static string FromExcelPath(string excelPath)
    {
        if (string.IsNullOrWhiteSpace(excelPath))
            throw new ArgumentException("Excel path is required.", nameof(excelPath));

        var directory = Path.GetDirectoryName(excelPath);
        var name = Path.GetFileNameWithoutExtension(excelPath);
        if (string.IsNullOrEmpty(name))
            throw new ArgumentException("Excel path has no file name.", nameof(excelPath));

        return string.IsNullOrEmpty(directory)
            ? name + ".pdf"
            : Path.Combine(directory, name + ".pdf");
    }
}
```

- [x] **Step 4: Run tests — expect pass**

Run:

```powershell
dotnet test "D:\files\projects\netcore\wpf\ExcelToPdf\ExcelToPdf\ExcelToPdf.Tests\ExcelToPdf.Tests.csproj"
```

Expected: PASS (all tests).

- [x] **Step 5: Commit** (skipped — no `.git`)

### Task 2: ConversionOptions, StaRunner, ComRelease

**Files:**
- Create: `ExcelToPdf/Models/ConversionOptions.cs`
- Create: `ExcelToPdf/Services/StaRunner.cs`
- Create: `ExcelToPdf/Services/ComRelease.cs`

- [x] **Step 1: Add ConversionOptions**

Create `ExcelToPdf/Models/ConversionOptions.cs`:

```csharp
namespace ExcelToPdf.Models;

public sealed class ConversionOptions
{
    public required string InputPath { get; init; }
    public required string OutputPath { get; init; }
    public bool FitSheetToOnePdfPage { get; init; }
}
```

- [x] **Step 2: Add StaRunner**

Create `ExcelToPdf/Services/StaRunner.cs`:

```csharp
namespace ExcelToPdf.Services;

public static class StaRunner
{
    public static Task Run(Action action)
    {
        ArgumentNullException.ThrowIfNull(action);

        var tcs = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var thread = new Thread(() =>
        {
            try
            {
                action();
                tcs.TrySetResult();
            }
            catch (Exception ex)
            {
                tcs.TrySetException(ex);
            }
        });

        thread.SetApartmentState(ApartmentState.STA);
        thread.IsBackground = true;
        thread.Name = "ExcelToPdf-STA";
        thread.Start();
        return tcs.Task;
    }
}
```

- [x] **Step 3: Add ComRelease**

Create `ExcelToPdf/Services/ComRelease.cs`:

```csharp
using System.Runtime.InteropServices;

namespace ExcelToPdf.Services;

public static class ComRelease
{
    public static void Safe(object? comObject)
    {
        if (comObject is null)
            return;

        try
        {
            if (Marshal.IsComObject(comObject))
                Marshal.FinalReleaseComObject(comObject);
        }
        catch
        {
            // Cleanup must not throw.
        }
    }
}
```

- [x] **Step 4: Build the app project and re-run tests**

Run:

```powershell
dotnet build "D:\files\projects\netcore\wpf\ExcelToPdf\ExcelToPdf\ExcelToPdf\ExcelToPdf.csproj"
dotnet test "D:\files\projects\netcore\wpf\ExcelToPdf\ExcelToPdf\ExcelToPdf.Tests\ExcelToPdf.Tests.csproj"
```

Expected: Build succeeded, 0 errors. Tests PASS.

- [x] **Step 5: Commit** (skipped — no `.git`)

---

## Chunk 2: Excel COM converter and WPF UI

### Task 3: Interop package + ExcelToPdfConverter

**Files:**
- Modify: `ExcelToPdf/ExcelToPdf.csproj`
- Create: `ExcelToPdf/Services/ExcelToPdfConverter.cs`

- [x] **Step 1: Add Interop package**

Set `ExcelToPdf/ExcelToPdf.csproj` to:

```xml
<Project Sdk="Microsoft.NET.Sdk">

  <PropertyGroup>
    <OutputType>WinExe</OutputType>
    <TargetFramework>net10.0-windows</TargetFramework>
    <Nullable>enable</Nullable>
    <ImplicitUsings>enable</ImplicitUsings>
    <UseWPF>true</UseWPF>
  </PropertyGroup>

  <ItemGroup>
    <PackageReference Include="Microsoft.Office.Interop.Excel" Version="15.0.4795.1001" />
  </ItemGroup>

</Project>
```

Run:

```powershell
dotnet restore "D:\files\projects\netcore\wpf\ExcelToPdf\ExcelToPdf\ExcelToPdf\ExcelToPdf.csproj"
```

Expected: restore succeeded.

- [x] **Step 2: Implement ExcelToPdfConverter**

Create `ExcelToPdf/Services/ExcelToPdfConverter.cs` with the full implementation below. Do not split this into stubs.

```csharp
using System.Runtime.InteropServices;
using ExcelToPdf.Models;
using Excel = Microsoft.Office.Interop.Excel;

namespace ExcelToPdf.Services;

public sealed class ExcelToPdfConverter
{
    public Task ConvertAsync(ConversionOptions options)
    {
        ArgumentNullException.ThrowIfNull(options);
        return StaRunner.Run(() => ConvertOnSta(options));
    }

    private static void ConvertOnSta(ConversionOptions options)
    {
        if (!File.Exists(options.InputPath))
            throw new FileNotFoundException("Excel 文件不存在或无法访问。", options.InputPath);

        Excel.Application? app = null;
        Excel.Workbooks? workbooks = null;
        Excel.Workbook? workbook = null;
        var backups = new List<(Excel.PageSetup Setup, object Zoom, object Wide, object Tall)>();

        try
        {
            try
            {
                app = new Excel.Application
                {
                    Visible = false,
                    DisplayAlerts = false,
                    ScreenUpdating = false
                };
            }
            catch (COMException ex)
            {
                throw new InvalidOperationException("未检测到桌面版 Microsoft Excel，请先安装后再转换。", ex);
            }

            workbooks = app.Workbooks;
            try
            {
                workbook = workbooks.Open(
                    Filename: options.InputPath,
                    UpdateLinks: 0,
                    ReadOnly: true,
                    IgnoreReadOnlyRecommended: true,
                    Password: "",
                    WriteResPassword: "");
            }
            catch (COMException ex) when (IsPasswordError(ex))
            {
                throw new InvalidOperationException("该文件受密码保护，无法打开。", ex);
            }
            catch (COMException ex)
            {
                throw new IOException("无法打开 Excel 文件，文件可能无效或已被占用。", ex);
            }

            EnsureHasVisibleSheets(workbook);

            if (options.FitSheetToOnePdfPage)
                backups = ApplyFitToVisibleWorksheets(workbook);

            try
            {
                workbook.ExportAsFixedFormat(
                    Type: Excel.XlFixedFormatType.xlTypePDF,
                    Filename: options.OutputPath,
                    Quality: Excel.XlFixedFormatQuality.xlQualityStandard,
                    IncludeDocProperties: true,
                    IgnorePrintAreas: options.FitSheetToOnePdfPage,
                    OpenAfterPublish: false);
            }
            catch (COMException ex) when (IsFileLocked(ex, options.OutputPath))
            {
                throw new IOException("PDF 文件被占用，请关闭正在使用该 PDF 的程序后重试。", ex);
            }
            catch (COMException ex)
            {
                throw new InvalidOperationException("导出 PDF 失败：" + ex.Message, ex);
            }
        }
        finally
        {
            RestorePageSetups(backups);

            if (workbook is not null)
            {
                try { workbook.Close(SaveChanges: false); }
                catch { /* cleanup */ }
            }

            if (app is not null)
            {
                try { app.Quit(); }
                catch { /* cleanup */ }
            }

            ComRelease.Safe(workbook);
            ComRelease.Safe(workbooks);
            ComRelease.Safe(app);
            workbook = null;
            workbooks = null;
            app = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }
    }

    private static void EnsureHasVisibleSheets(Excel.Workbook workbook)
    {
        var sheets = workbook.Sheets;
        try
        {
            var count = 0;
            foreach (object sheet in sheets)
            {
                try
                {
                    if (IsVisibleSheet(sheet))
                        count++;
                }
                finally
                {
                    ComRelease.Safe(sheet);
                }
            }

            if (count == 0)
                throw new InvalidOperationException("没有可见工作表可导出。");
        }
        finally
        {
            ComRelease.Safe(sheets);
        }
    }

    private static bool IsVisibleSheet(object sheet)
    {
        return sheet switch
        {
            Excel._Worksheet ws => ws.Visible == Excel.XlSheetVisibility.xlSheetVisible,
            Excel.Chart chart => chart.Visible == Excel.XlSheetVisibility.xlSheetVisible,
            _ => false
        };
    }

    private static List<(Excel.PageSetup Setup, object Zoom, object Wide, object Tall)> ApplyFitToVisibleWorksheets(
        Excel.Workbook workbook)
    {
        var backups = new List<(Excel.PageSetup Setup, object Zoom, object Wide, object Tall)>();
        var worksheets = workbook.Worksheets;
        try
        {
            foreach (Excel._Worksheet ws in worksheets)
            {
                try
                {
                    if (ws.Visible != Excel.XlSheetVisibility.xlSheetVisible)
                        continue;

                    var setup = ws.PageSetup;
                    backups.Add((setup, setup.Zoom, setup.FitToPagesWide, setup.FitToPagesTall));
                    setup.Zoom = false;
                    setup.FitToPagesWide = 1;
                    setup.FitToPagesTall = 1;
                }
                finally
                {
                    ComRelease.Safe(ws);
                }
            }
        }
        finally
        {
            ComRelease.Safe(worksheets);
        }

        return backups;
    }

    private static void RestorePageSetups(
        List<(Excel.PageSetup Setup, object Zoom, object Wide, object Tall)> backups)
    {
        foreach (var (setup, zoom, wide, tall) in backups)
        {
            try
            {
                setup.Zoom = zoom;
                setup.FitToPagesWide = wide;
                setup.FitToPagesTall = tall;
            }
            catch
            {
                // Restore is best-effort; workbook is closed without saving.
            }
            finally
            {
                ComRelease.Safe(setup);
            }
        }
    }

    private static bool IsPasswordError(COMException ex)
    {
        // Excel password / encrypted workbook HRESULT variants.
        return ex.ErrorCode is unchecked((int)0x800A03EC) or unchecked((int)0x800A1066)
            || (ex.Message?.Contains("Password", StringComparison.OrdinalIgnoreCase) ?? false)
            || (ex.Message?.Contains("密码", StringComparison.OrdinalIgnoreCase) ?? false);
    }

    private static bool IsFileLocked(COMException ex, string outputPath)
    {
        if (File.Exists(outputPath))
        {
            try
            {
                using var _ = new FileStream(outputPath, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            }
            catch (IOException)
            {
                return true;
            }
        }

        return ex.ErrorCode == unchecked((int)0x80030020)
            || (ex.Message?.Contains("in use", StringComparison.OrdinalIgnoreCase) ?? false);
    }
}
```

- [x] **Step 3: Build converter**

Run:

```powershell
dotnet build "D:\files\projects\netcore\wpf\ExcelToPdf\ExcelToPdf\ExcelToPdf\ExcelToPdf.csproj"
```

Expected: Build succeeded. If Interop types fail (`_Worksheet` / `Chart.Visible`), fix compile errors against the installed Interop (use `Excel.Worksheet` instead of `Excel._Worksheet` if needed). Do not change behavior.

- [x] **Step 4: Commit** (skipped — no `.git`)

### Task 4: MainWindow UI

**Files:**
- Modify: `ExcelToPdf/MainWindow.xaml`
- Modify: `ExcelToPdf/MainWindow.xaml.cs`

- [x] **Step 1: Replace MainWindow.xaml**

```xml
<Window x:Class="ExcelToPdf.MainWindow"
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Excel → PDF"
        Height="280" Width="640"
        MinHeight="260" MinWidth="520"
        WindowStartupLocation="CenterScreen">
    <Grid Margin="16">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
        </Grid.RowDefinitions>
        <Grid.ColumnDefinitions>
            <ColumnDefinition Width="Auto"/>
            <ColumnDefinition Width="*"/>
            <ColumnDefinition Width="Auto"/>
        </Grid.ColumnDefinitions>

        <TextBlock Grid.Row="0" Grid.Column="0" Text="Excel 文件" VerticalAlignment="Center" Margin="0,0,12,8"/>
        <TextBox x:Name="ExcelPathBox" Grid.Row="0" Grid.Column="1" Margin="0,0,8,8" IsReadOnly="True"/>
        <Button Grid.Row="0" Grid.Column="2" Content="浏览…" Width="88" Margin="0,0,0,8" Click="Browse_Click"/>

        <TextBlock Grid.Row="1" Grid.Column="0" Text="输出 PDF" VerticalAlignment="Center" Margin="0,0,12,8"/>
        <TextBox x:Name="PdfPathBox" Grid.Row="1" Grid.Column="1" Grid.ColumnSpan="2" Margin="0,0,0,8" IsReadOnly="True"/>

        <CheckBox x:Name="FitCheckBox"
                  Grid.Row="2" Grid.Column="0" Grid.ColumnSpan="3"
                  Content="每个工作表缩放到一张 PDF 页"
                  Margin="0,4,0,12"/>

        <Button x:Name="ConvertButton"
                Grid.Row="3" Grid.Column="0" Grid.ColumnSpan="3"
                Content="开始转换"
                Height="32"
                Click="Convert_Click"/>

        <TextBlock x:Name="StatusText"
                   Grid.Row="4" Grid.Column="0" Grid.ColumnSpan="3"
                   TextWrapping="Wrap"
                   VerticalAlignment="Top"
                   Margin="0,12,0,0"
                   Foreground="#555"/>
    </Grid>
</Window>
```

- [x] **Step 2: Replace MainWindow.xaml.cs**

```csharp
using System.IO;
using System.Windows;
using ExcelToPdf.Models;
using ExcelToPdf.Services;
using Microsoft.Win32;

namespace ExcelToPdf;

public partial class MainWindow : Window
{
    private readonly ExcelToPdfConverter _converter = new();
    private bool _busy;

    public MainWindow()
    {
        InitializeComponent();
        StatusText.Text = "选择一个 Excel 文件。";
    }

    private void Browse_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Filter = "Excel 文件|*.xlsx;*.xls;*.xlsm|所有文件|*.*",
            Title = "选择 Excel 文件"
        };

        if (dialog.ShowDialog() != true)
            return;

        ExcelPathBox.Text = dialog.FileName;
        PdfPathBox.Text = PdfOutputPath.FromExcelPath(dialog.FileName);
        StatusText.Text = "就绪。";
    }

    private async void Convert_Click(object sender, RoutedEventArgs e)
    {
        if (_busy)
            return;

        var input = ExcelPathBox.Text;
        if (string.IsNullOrWhiteSpace(input) || !File.Exists(input))
        {
            StatusText.Text = "请先选择有效的 Excel 文件。";
            return;
        }

        var output = PdfPathBox.Text;
        if (File.Exists(output))
        {
            var overwrite = MessageBox.Show(
                $"文件已存在，是否覆盖？\n{output}",
                "覆盖确认",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);
            if (overwrite != MessageBoxResult.Yes)
            {
                StatusText.Text = "已取消。";
                return;
            }
        }

        _busy = true;
        ConvertButton.IsEnabled = false;
        StatusText.Text = "正在转换…";

        try
        {
            await _converter.ConvertAsync(new ConversionOptions
            {
                InputPath = input,
                OutputPath = output,
                FitSheetToOnePdfPage = FitCheckBox.IsChecked == true
            });

            StatusText.Text = "完成：" + output;
        }
        catch (Exception ex)
        {
            StatusText.Text = ex.Message;
        }
        finally
        {
            _busy = false;
            ConvertButton.IsEnabled = true;
        }
    }
}
```

- [x] **Step 3: Build solution**

Run:

```powershell
dotnet build "D:\files\projects\netcore\wpf\ExcelToPdf\ExcelToPdf"
```

Expected: Build succeeded, 0 errors.

- [x] **Step 4: Run unit tests again**

```powershell
dotnet test "D:\files\projects\netcore\wpf\ExcelToPdf\ExcelToPdf\ExcelToPdf.Tests\ExcelToPdf.Tests.csproj"
```

Expected: PASS.

- [x] **Step 5: Commit** (skipped — no `.git`)

### Task 5: Manual verification (requires Excel)

Do this on the machine with desktop Excel installed. If Excel is missing, record that COM-create error shows “未检测到桌面版 Microsoft Excel”.

- [ ] **Step 1: Run the app**

```powershell
dotnet run --project "D:\files\projects\netcore\wpf\ExcelToPdf\ExcelToPdf\ExcelToPdf\ExcelToPdf.csproj"
```

Expected: Window titled “Excel → PDF” with browse, output path, checkbox, convert button. No Cancel button. Convert disables while running.

- [ ] **Step 2: Convert with fit OFF**

Use a workbook with **multiple visible sheets in a known tab order**. Leave checkbox unchecked. Confirm PDF appears next to the Excel file; **page/sheet order matches tab order**; pagination matches print preview (including print area). Hidden and very-hidden sheets are absent. Task Manager: no leftover `EXCEL.EXE` after finish.

- [ ] **Step 3: Convert with fit ON**

Check “每个工作表缩放到一张 PDF 页”. Each **visible worksheet** is one PDF page. Hidden / very-hidden sheets absent. If the file has a **visible chart sheet**, it is in the PDF (Excel default print, not worksheet 1×1 fit). Source `.xlsx` last-write time unchanged.

- [ ] **Step 4: Overwrite prompt and locked PDF**

Convert again to the same PDF. Expect Yes/No dialog. No = status “已取消。” and file not rewritten. Then open the PDF in a viewer that locks the file, convert with Yes: status explains the PDF is in use; after dismiss, no leftover `EXCEL.EXE`.

- [ ] **Step 5: Failure paths still clean up Excel**

Password-protected workbook: short error; no leftover `EXCEL.EXE`. Workbook with **zero visible sheets**: “没有可见工作表可导出。” (or the UI shows that message); no leftover `EXCEL.EXE`.

- [ ] **Step 6: Commit** (skip if no `.git`) only if code was fixed during verification

```bash
git add -u
git commit -m "fix: conversion issues found in manual Excel checks"
```
