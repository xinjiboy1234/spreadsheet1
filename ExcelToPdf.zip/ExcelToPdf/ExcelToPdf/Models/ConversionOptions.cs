namespace ExcelToPdf.Models;

public sealed class ConversionOptions
{
    public required string InputPath { get; init; }
    public required string OutputPath { get; init; }
    public bool FitSheetToOnePdfPage { get; init; }
    public PaperSizeSettings Paper { get; init; } = new();
}
