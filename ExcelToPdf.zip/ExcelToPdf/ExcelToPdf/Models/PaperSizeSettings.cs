namespace ExcelToPdf.Models;

public enum PaperPreset
{
    A4,
    A3,
    A5,
    Letter,
    Legal
}

public enum PaperMode
{
    Preset,
    Custom
}

public sealed class PaperSizeSettings
{
    public PaperMode Mode { get; init; } = PaperMode.Preset;
    public PaperPreset Preset { get; init; } = PaperPreset.A4;
    public bool Landscape { get; init; }
    public double WidthPx { get; init; }
    public double HeightPx { get; init; }
    public double Dpi { get; init; } = 96;
}
