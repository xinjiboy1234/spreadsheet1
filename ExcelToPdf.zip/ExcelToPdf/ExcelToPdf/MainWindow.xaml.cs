﻿using System.Globalization;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using ExcelToPdf.Models;
using ExcelToPdf.Services;
using Microsoft.Win32;

namespace ExcelToPdf;

public partial class MainWindow : Window
{
    private readonly ExcelToPdfConverter _converter = new();
    private bool _busy;

    public MainWindow()
    {
        InitializeComponent();
        StatusText.Text = "选择一个 Excel 文件。";
        UpdatePaperUiState();
    }

    private void Browse_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Filter = "Excel 文件|*.xlsx;*.xls;*.xlsm|所有文件|*.*",
            Title = "选择 Excel 文件"
        };

        if (dialog.ShowDialog() != true)
            return;

        ExcelPathBox.Text = dialog.FileName;
        PdfPathBox.Text = PdfOutputPath.FromExcelPath(dialog.FileName);
        StatusText.Text = "就绪。";
    }

    private void PaperPresetBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!IsLoaded)
            return;

        UpdatePaperUiState();
    }

    private void UpdatePaperUiState()
    {
        var custom = IsCustomPaperSelected();
        WidthPxBox.IsEnabled = custom;
        HeightPxBox.IsEnabled = custom;
        DpiBox.IsEnabled = custom;
        OrientationBox.IsEnabled = !custom;
    }

    private bool IsCustomPaperSelected()
    {
        return PaperPresetBox.SelectedItem is ComboBoxItem item
            && string.Equals(item.Tag as string, "Custom", StringComparison.Ordinal);
    }

    private async void Convert_Click(object sender, RoutedEventArgs e)
    {
        if (_busy)
            return;

        var input = ExcelPathBox.Text;
        if (string.IsNullOrWhiteSpace(input) || !File.Exists(input))
        {
            StatusText.Text = "请先选择有效的 Excel 文件。";
            return;
        }

        if (!TryBuildPaperSettings(out var paper, out var paperError))
        {
            StatusText.Text = paperError;
            return;
        }

        if (!PaperSizeHelper.TryValidate(paper, out var validateError))
        {
            StatusText.Text = validateError;
            return;
        }

        var output = PdfPathBox.Text;
        if (File.Exists(output))
        {
            var overwrite = MessageBox.Show(
                $"文件已存在，是否覆盖？\n{output}",
                "覆盖确认",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);
            if (overwrite != MessageBoxResult.Yes)
            {
                StatusText.Text = "已取消。";
                return;
            }
        }

        _busy = true;
        ConvertButton.IsEnabled = false;
        StatusText.Text = "正在转换…";

        try
        {
            await _converter.ConvertAsync(new ConversionOptions
            {
                InputPath = input,
                OutputPath = output,
                FitSheetToOnePdfPage = FitCheckBox.IsChecked == true,
                Paper = paper
            });

            StatusText.Text = "完成：" + output;
        }
        catch (Exception ex)
        {
            StatusText.Text = ex.Message;
        }
        finally
        {
            _busy = false;
            ConvertButton.IsEnabled = true;
        }
    }

    private bool TryBuildPaperSettings(out PaperSizeSettings paper, out string error)
    {
        paper = new PaperSizeSettings();
        error = string.Empty;

        if (PaperPresetBox.SelectedItem is not ComboBoxItem presetItem
            || presetItem.Tag is not string tag)
        {
            error = "请选择纸张。";
            return false;
        }

        if (tag == "Custom")
        {
            if (!TryParsePositive(WidthPxBox.Text, "宽度", out var width, out error)
                || !TryParsePositive(HeightPxBox.Text, "高度", out var height, out error)
                || !TryParsePositive(DpiBox.Text, "DPI", out var dpi, out error))
            {
                return false;
            }

            paper = new PaperSizeSettings
            {
                Mode = PaperMode.Custom,
                WidthPx = width,
                HeightPx = height,
                Dpi = dpi
            };
            return true;
        }

        if (!Enum.TryParse<PaperPreset>(tag, ignoreCase: true, out var preset))
        {
            error = "未知的纸张预设。";
            return false;
        }

        var landscape = OrientationBox.SelectedItem is ComboBoxItem ori
            && string.Equals(ori.Tag as string, "Landscape", StringComparison.Ordinal);

        paper = new PaperSizeSettings
        {
            Mode = PaperMode.Preset,
            Preset = preset,
            Landscape = landscape
        };
        return true;
    }

    private static bool TryParsePositive(string text, string label, out double value, out string error)
    {
        error = string.Empty;
        if (!double.TryParse(text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out value)
            && !double.TryParse(text.Trim(), NumberStyles.Float, CultureInfo.CurrentCulture, out value))
        {
            error = $"{label} 不是有效数字。";
            return false;
        }

        if (value <= 0)
        {
            error = $"{label} 必须大于 0。";
            return false;
        }

        return true;
    }
}
