using System.Runtime.InteropServices;

namespace ExcelToPdf.Services;

public static class ComRelease
{
    public static void Safe(object? comObject)
    {
        if (comObject is null)
            return;

        try
        {
            if (Marshal.IsComObject(comObject))
                Marshal.FinalReleaseComObject(comObject);
        }
        catch
        {
            // Cleanup must not throw.
        }
    }
}
