using System.Runtime.InteropServices;
using ExcelToPdf.Models;
using Excel = Microsoft.Office.Interop.Excel;

namespace ExcelToPdf.Services;

public sealed class ExcelToPdfConverter
{
    public Task ConvertAsync(ConversionOptions options)
    {
        ArgumentNullException.ThrowIfNull(options);
        return StaRunner.Run(() => ConvertOnSta(options));
    }

    private static void ConvertOnSta(ConversionOptions options)
    {
        if (!File.Exists(options.InputPath))
            throw new FileNotFoundException("Excel 文件不存在或无法访问。", options.InputPath);

        if (!PaperSizeHelper.TryValidate(options.Paper, out var paperError))
            throw new InvalidOperationException(paperError);

        string? tempPath = null;
        Excel.Application? app = null;
        Excel.Workbooks? workbooks = null;
        Excel.Workbook? workbook = null;

        try
        {
            tempPath = CreateTempCopy(options.InputPath);

            try
            {
                app = new Excel.Application
                {
                    Visible = false,
                    DisplayAlerts = false,
                    ScreenUpdating = false
                };
            }
            catch (COMException ex)
            {
                throw new InvalidOperationException("未检测到桌面版 Microsoft Excel，请先安装后再转换。", ex);
            }

            workbooks = app.Workbooks;
            try
            {
                workbook = workbooks.Open(
                    Filename: tempPath,
                    UpdateLinks: 0,
                    ReadOnly: false,
                    IgnoreReadOnlyRecommended: true,
                    Password: "",
                    WriteResPassword: "");
            }
            catch (COMException ex) when (IsPasswordError(ex))
            {
                throw new InvalidOperationException("该文件受密码保护，无法打开。", ex);
            }
            catch (COMException ex)
            {
                throw new IOException("无法打开 Excel 文件，文件可能无效或已被占用。", ex);
            }

            EnsureHasVisibleSheets(workbook);
            ApplyPaperToVisibleWorksheets(workbook, options.Paper);

            if (options.FitSheetToOnePdfPage)
                ApplyFitToVisibleWorksheets(workbook);

            try
            {
                workbook.ExportAsFixedFormat(
                    Type: Excel.XlFixedFormatType.xlTypePDF,
                    Filename: options.OutputPath,
                    Quality: Excel.XlFixedFormatQuality.xlQualityStandard,
                    IncludeDocProperties: true,
                    IgnorePrintAreas: options.FitSheetToOnePdfPage,
                    OpenAfterPublish: false);
            }
            catch (COMException ex) when (IsFileLocked(ex, options.OutputPath))
            {
                throw new IOException("PDF 文件被占用，请关闭正在使用该 PDF 的程序后重试。", ex);
            }
            catch (COMException ex)
            {
                throw new InvalidOperationException("导出 PDF 失败：" + ex.Message, ex);
            }
        }
        finally
        {
            if (workbook is not null)
            {
                try { workbook.Close(SaveChanges: false); }
                catch { /* cleanup */ }
            }

            if (app is not null)
            {
                try { app.Quit(); }
                catch { /* cleanup */ }
            }

            ComRelease.Safe(workbook);
            ComRelease.Safe(workbooks);
            ComRelease.Safe(app);
            workbook = null;
            workbooks = null;
            app = null;
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
            GC.WaitForPendingFinalizers();

            TryDeleteTemp(tempPath);
        }
    }

    private static string CreateTempCopy(string inputPath)
    {
        try
        {
            var dir = Path.Combine(Path.GetTempPath(), "ExcelToPdf");
            Directory.CreateDirectory(dir);
            var ext = Path.GetExtension(inputPath);
            var tempPath = Path.Combine(dir, Guid.NewGuid().ToString("N") + ext);
            File.Copy(inputPath, tempPath, overwrite: false);
            return tempPath;
        }
        catch (Exception ex)
        {
            throw new IOException("无法创建临时副本。", ex);
        }
    }

    private static void TryDeleteTemp(string? tempPath)
    {
        if (string.IsNullOrEmpty(tempPath))
            return;

        try
        {
            if (File.Exists(tempPath))
                File.Delete(tempPath);
        }
        catch
        {
            // Best-effort; do not fail a successful export.
        }
    }

    private static void EnsureHasVisibleSheets(Excel.Workbook workbook)
    {
        var sheets = workbook.Sheets;
        try
        {
            var count = 0;
            foreach (object sheet in sheets)
            {
                try
                {
                    if (IsVisibleSheet(sheet))
                        count++;
                }
                finally
                {
                    ComRelease.Safe(sheet);
                }
            }

            if (count == 0)
                throw new InvalidOperationException("没有可见工作表可导出。");
        }
        finally
        {
            ComRelease.Safe(sheets);
        }
    }

    private static bool IsVisibleSheet(object sheet)
    {
        return sheet switch
        {
            Excel._Worksheet ws => ws.Visible == Excel.XlSheetVisibility.xlSheetVisible,
            Excel.Chart chart => chart.Visible == Excel.XlSheetVisibility.xlSheetVisible,
            _ => false
        };
    }

    private static void ApplyPaperToVisibleWorksheets(Excel.Workbook workbook, PaperSizeSettings paper)
    {
        var worksheets = workbook.Worksheets;
        try
        {
            foreach (Excel._Worksheet ws in worksheets)
            {
                try
                {
                    if (ws.Visible != Excel.XlSheetVisibility.xlSheetVisible)
                        continue;

                    var setup = ws.PageSetup;
                    try
                    {
                        if (paper.Mode == PaperMode.Custom)
                        {
                            var (widthInches, heightInches) = PaperSizeHelper.ToInches(paper);
                            // xlPaperUser = 256; PageWidth/Height not on older Interop PIAs — use dynamic.
                            setup.PaperSize = (Excel.XlPaperSize)256;
                            setup.Orientation = Excel.XlPageOrientation.xlPortrait;
                            dynamic dynSetup = setup;
                            dynSetup.PageWidth = widthInches;
                            dynSetup.PageHeight = heightInches;
                        }
                        else
                        {
                            setup.PaperSize = MapPreset(paper.Preset);
                            setup.Orientation = paper.Landscape
                                ? Excel.XlPageOrientation.xlLandscape
                                : Excel.XlPageOrientation.xlPortrait;
                        }
                    }
                    finally
                    {
                        ComRelease.Safe(setup);
                    }
                }
                finally
                {
                    ComRelease.Safe(ws);
                }
            }
        }
        finally
        {
            ComRelease.Safe(worksheets);
        }
    }

    private static Excel.XlPaperSize MapPreset(PaperPreset preset) => preset switch
    {
        PaperPreset.A4 => Excel.XlPaperSize.xlPaperA4,
        PaperPreset.A3 => Excel.XlPaperSize.xlPaperA3,
        PaperPreset.A5 => Excel.XlPaperSize.xlPaperA5,
        PaperPreset.Letter => Excel.XlPaperSize.xlPaperLetter,
        PaperPreset.Legal => Excel.XlPaperSize.xlPaperLegal,
        _ => Excel.XlPaperSize.xlPaperA4
    };

    private static void ApplyFitToVisibleWorksheets(Excel.Workbook workbook)
    {
        var worksheets = workbook.Worksheets;
        try
        {
            foreach (Excel._Worksheet ws in worksheets)
            {
                try
                {
                    if (ws.Visible != Excel.XlSheetVisibility.xlSheetVisible)
                        continue;

                    var setup = ws.PageSetup;
                    try
                    {
                        setup.Zoom = false;
                        setup.FitToPagesWide = 1;
                        setup.FitToPagesTall = 1;
                    }
                    finally
                    {
                        ComRelease.Safe(setup);
                    }
                }
                finally
                {
                    ComRelease.Safe(ws);
                }
            }
        }
        finally
        {
            ComRelease.Safe(worksheets);
        }
    }

    private static bool IsPasswordError(COMException ex)
    {
        return ex.ErrorCode is unchecked((int)0x800A03EC) or unchecked((int)0x800A1066)
            || (ex.Message?.Contains("Password", StringComparison.OrdinalIgnoreCase) ?? false)
            || (ex.Message?.Contains("密码", StringComparison.OrdinalIgnoreCase) ?? false);
    }

    private static bool IsFileLocked(COMException ex, string outputPath)
    {
        if (File.Exists(outputPath))
        {
            try
            {
                using var _ = new FileStream(outputPath, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
            }
            catch (IOException)
            {
                return true;
            }
        }

        return ex.ErrorCode == unchecked((int)0x80030020)
            || (ex.Message?.Contains("in use", StringComparison.OrdinalIgnoreCase) ?? false);
    }
}
