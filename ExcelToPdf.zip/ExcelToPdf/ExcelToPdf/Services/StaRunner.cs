namespace ExcelToPdf.Services;

public static class StaRunner
{
    public static Task Run(Action action)
    {
        ArgumentNullException.ThrowIfNull(action);

        var tcs = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var thread = new Thread(() =>
        {
            try
            {
                action();
                tcs.TrySetResult();
            }
            catch (Exception ex)
            {
                tcs.TrySetException(ex);
            }
        });

        thread.SetApartmentState(ApartmentState.STA);
        // Foreground so the process does not exit mid-Excel COM cleanup if the UI closes.
        thread.IsBackground = false;
        thread.Name = "ExcelToPdf-STA";
        thread.Start();
        return tcs.Task;
    }
}
