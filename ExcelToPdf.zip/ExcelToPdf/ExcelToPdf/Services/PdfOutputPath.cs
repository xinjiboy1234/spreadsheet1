namespace ExcelToPdf.Services;

public static class PdfOutputPath
{
    public static string FromExcelPath(string excelPath)
    {
        if (string.IsNullOrWhiteSpace(excelPath))
            throw new ArgumentException("Excel path is required.", nameof(excelPath));

        var directory = Path.GetDirectoryName(excelPath);
        var name = Path.GetFileNameWithoutExtension(excelPath);
        if (string.IsNullOrEmpty(name))
            throw new ArgumentException("Excel path has no file name.", nameof(excelPath));

        return string.IsNullOrEmpty(directory)
            ? name + ".pdf"
            : Path.Combine(directory, name + ".pdf");
    }
}
