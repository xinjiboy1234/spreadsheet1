using ExcelToPdf.Models;

namespace ExcelToPdf.Services;

public static class PaperSizeHelper
{
    public const double MinInches = 0.1;
    public const double MaxInches = 22.0;

    public static bool TryValidate(PaperSizeSettings paper, out string errorMessage)
    {
        ArgumentNullException.ThrowIfNull(paper);

        if (paper.Mode == PaperMode.Preset)
        {
            errorMessage = string.Empty;
            return true;
        }

        if (paper.Dpi <= 0)
        {
            errorMessage = "DPI 必须大于 0。";
            return false;
        }

        if (paper.WidthPx <= 0 || paper.HeightPx <= 0)
        {
            errorMessage = "自定义纸张宽高（像素）必须大于 0。";
            return false;
        }

        var (widthInches, heightInches) = ToInches(paper);
        if (widthInches < MinInches || widthInches > MaxInches
            || heightInches < MinInches || heightInches > MaxInches)
        {
            errorMessage = $"换算后的纸张尺寸必须在 {MinInches}–{MaxInches} 英寸之间。";
            return false;
        }

        errorMessage = string.Empty;
        return true;
    }

    public static (double WidthInches, double HeightInches) ToInches(PaperSizeSettings paper)
    {
        ArgumentNullException.ThrowIfNull(paper);
        if (paper.Mode != PaperMode.Custom)
            throw new InvalidOperationException("ToInches 仅适用于自定义纸张。");

        return (paper.WidthPx / paper.Dpi, paper.HeightPx / paper.Dpi);
    }
}
