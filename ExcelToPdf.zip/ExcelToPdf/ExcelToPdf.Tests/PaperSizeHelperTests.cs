using ExcelToPdf.Models;
using ExcelToPdf.Services;
using Xunit;

namespace ExcelToPdf.Tests;

public class PaperSizeHelperTests
{
    [Fact]
    public void TryValidate_preset_always_ok()
    {
        var ok = PaperSizeHelper.TryValidate(new PaperSizeSettings(), out var error);
        Assert.True(ok);
        Assert.Equal(string.Empty, error);
    }

    [Fact]
    public void ToInches_converts_px_at_dpi()
    {
        var paper = new PaperSizeSettings
        {
            Mode = PaperMode.Custom,
            WidthPx = 794,
            HeightPx = 1123,
            Dpi = 96
        };

        var (w, h) = PaperSizeHelper.ToInches(paper);
        Assert.Equal(794.0 / 96.0, w, 5);
        Assert.Equal(1123.0 / 96.0, h, 5);
    }

    [Fact]
    public void ToInches_rejects_preset_mode()
    {
        Assert.Throws<InvalidOperationException>(() =>
            PaperSizeHelper.ToInches(new PaperSizeSettings { Mode = PaperMode.Preset }));
    }

    [Theory]
    [InlineData(0, 100, 96)]
    [InlineData(100, 0, 96)]
    [InlineData(100, 100, 0)]
    [InlineData(-1, 100, 96)]
    public void TryValidate_rejects_non_positive_custom(double w, double h, double dpi)
    {
        var paper = new PaperSizeSettings
        {
            Mode = PaperMode.Custom,
            WidthPx = w,
            HeightPx = h,
            Dpi = dpi
        };

        Assert.False(PaperSizeHelper.TryValidate(paper, out var error));
        Assert.False(string.IsNullOrWhiteSpace(error));
    }

    [Fact]
    public void TryValidate_rejects_out_of_range_inches()
    {
        var paper = new PaperSizeSettings
        {
            Mode = PaperMode.Custom,
            WidthPx = 1,
            HeightPx = 1,
            Dpi = 96
        };

        Assert.False(PaperSizeHelper.TryValidate(paper, out _));
    }

    [Fact]
    public void TryValidate_accepts_a4ish_custom()
    {
        var paper = new PaperSizeSettings
        {
            Mode = PaperMode.Custom,
            WidthPx = 794,
            HeightPx = 1123,
            Dpi = 96
        };

        Assert.True(PaperSizeHelper.TryValidate(paper, out var error));
        Assert.Equal(string.Empty, error);
    }
}
