using ExcelToPdf.Services;
using Xunit;

namespace ExcelToPdf.Tests;

public class PdfOutputPathTests
{
    [Fact]
    public void FromExcelPath_replaces_extension_with_pdf_same_directory()
    {
        var excel = @"D:\files\report.xlsx";
        var pdf = PdfOutputPath.FromExcelPath(excel);
        Assert.Equal(@"D:\files\report.pdf", pdf);
    }

    [Fact]
    public void FromExcelPath_handles_xlsm_and_xls()
    {
        Assert.EndsWith("a.pdf", PdfOutputPath.FromExcelPath(@"C:\t\a.xlsm"));
        Assert.EndsWith("b.pdf", PdfOutputPath.FromExcelPath(@"C:\t\b.xls"));
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("   ")]
    public void FromExcelPath_rejects_blank(string? path)
    {
        Assert.Throws<ArgumentException>(() => PdfOutputPath.FromExcelPath(path!));
    }
}
