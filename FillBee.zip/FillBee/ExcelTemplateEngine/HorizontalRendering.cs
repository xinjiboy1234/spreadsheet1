using System.Collections;
namespace FillBee;
internal static class HorizontalRendering
{
 public static void Apply(object worksheet,BindingScope scope,RenderOptions options,TemplateFormatters formatters,CancellationToken cancellation)
 {
  dynamic sheet=worksheet;object? used=null,columns=null,rows=null;
  try{used=sheet.UsedRange;columns=((dynamic)used).Columns;rows=((dynamic)used).Rows;int firstRow=((dynamic)used).Row,lastRow=firstRow+(int)((dynamic)rows).Count-1;int first=((dynamic)used).Column,last=first+(int)((dynamic)columns).Count-1;
   for(int column=first;column<=last;column++){string? expression=null;int markerRow=0;for(int row=firstRow;row<=lastRow;row++){var value=Read(sheet,row,column);if(value is string text&&text.Contains("direction=\"right\"")){expression=TemplateSyntax.Scan(text).Single().Expression;markerRow=row;break;}}if(expression is null)continue;
    cancellation.ThrowIfCancellationRequested();int close=column;while(++close<=last){if(Read(sheet,markerRow,close) is string end&&end.Trim()=="{{/each}}")break;}if(close>last)throw new FormatException("Horizontal loop has no closing marker on the same row.");
    var path=expression[6..expression.IndexOf("direction=",StringComparison.Ordinal)].Trim();var source=ValueResolver.Resolve(scope,path);var items=source is IEnumerable sequence&&source is not string?sequence.Cast<object?>().ToArray():source is null?[]:throw new InvalidOperationException($"{path} is not a collection.");int width=close-column-1;
    for(int i=1;i<items.Length&&width>0;i++){object? body=null,target=null;try{body=sheet.Range[$"{Letter(column+1)}:{Letter(close-1)}"];var address=$"{Letter(column+1+i*width)}:{Letter(column+(i+1)*width)}";target=sheet.Range[address];((dynamic)target).Insert(-4161);ComAccess.Release(target);target=sheet.Range[address];((dynamic)body).Copy(target);}finally{ComAccess.Release(target);ComAccess.Release(body);}}
    Delete(sheet,close+Math.Max(0,items.Length-1)*width,close+Math.Max(0,items.Length-1)*width);if(items.Length==0&&width>0)Delete(sheet,column+1,column+width);Delete(sheet,column,column);
    for(int i=0;i<items.Length;i++){var child=new BindingScope(items[i],scope.Root,scope,i+1,items.Length);for(int row=firstRow;row<=lastRow;row++)for(int c=column+i*width;c<column+(i+1)*width;c++){object? cells=null,cell=null;try{cells=sheet.Cells;cell=((dynamic)cells)[row,c];if(!(bool)((dynamic)cell).HasFormula&&((dynamic)cell).Value2 is string text&&text.Contains("{{"))((dynamic)cell).Value2=TemplateSyntax.Expand(text,child,options,formatters);}finally{ComAccess.Release(cell);ComAccess.Release(cells);}}}
    int total=width*items.Length;last+=total-width-2;column+=total-1;
   }
  }finally{ComAccess.Release(rows);ComAccess.Release(columns);ComAccess.Release(used);}
 }
 private static object? Read(dynamic sheet,int row,int col){object? cells=null,cell=null;try{cells=sheet.Cells;cell=((dynamic)cells)[row,col];return ((dynamic)cell).Value2;}finally{ComAccess.Release(cell);ComAccess.Release(cells);}}
 private static void Delete(dynamic sheet,int a,int b){object? range=null;try{range=sheet.Range[$"{Letter(a)}:{Letter(b)}"];((dynamic)range).Delete();}finally{ComAccess.Release(range);}}
 private static string Letter(int column){var s="";while(column>0){column--;s=(char)('A'+column%26)+s;column/=26;}return s;}
}
