using System.Text.RegularExpressions;
namespace FillBee;
internal sealed record TemplateToken(string Kind,string Expression,int Start,int Length);
internal static class TemplateSyntax
{
 private static readonly Regex Tokens=new(@"(?<!\\)\{\{\s*([^{}]+?)\s*\}\}",RegexOptions.Compiled);
 public static IEnumerable<TemplateToken> Scan(string text)=>Tokens.Matches(text).Select(m=>{var e=m.Groups[1].Value.Trim();return new TemplateToken(e.StartsWith('#')?"open":e.StartsWith('/')?"close":"value",e,m.Index,m.Length);});
 public static string Expand(string text,BindingScope scope,RenderOptions options,TemplateFormatters formatters,string? sheet=null,string? address=null)
 {
  var stack=new Stack<string>(); foreach(var t in Scan(text)){if(t.Kind=="open")stack.Push(t.Expression);else if(t.Kind=="close"&&(stack.Count==0||!Matches(stack.Pop(),t.Expression)))throw new FormatException($"Unbalanced directive at {sheet}!{address}.");} if(stack.Count>0)throw new FormatException($"Unclosed directive at {sheet}!{address}.");
  return Tokens.Replace(text,m=>{var exp=m.Groups[1].Value.Trim();if(exp.StartsWith('#')||exp.StartsWith('/'))return m.Value;var parts=exp.Split('|',2);var path=parts[0].Trim();var value=ValueResolver.Resolve(scope,path);if(value is null&&options.MissingValue==MissingValueBehavior.Throw)throw new KeyNotFoundException($"Missing '{path}' at {sheet}!{address}.");if(parts.Length>1){var fmt=parts[1].Trim();var colon=fmt.IndexOf(':');var name=colon<0?fmt:fmt[..colon].Trim();var arg=colon<0?null:fmt[(colon+1)..].Trim().Trim('\'', '"');if(!formatters.TryFormat(name,value,arg,out value))throw new FormatException($"Unknown formatter '{name}'.");}return Convert.ToString(value,System.Globalization.CultureInfo.CurrentCulture)??"";}).Replace(@"\{{","{{");
 }
 private static bool Matches(string o,string c)=>(o.StartsWith("#each")&&c.StartsWith("/each"))||(o.StartsWith("#if")&&c.StartsWith("/if"));
}
