using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text.Json;

namespace FillBee;

internal static class ExcelOwnership
{
    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(nint hwnd, out uint pid);

    public static void Record(dynamic app)
    {
        var file = Environment.GetEnvironmentVariable("FILLBEE_OWNER_FILE");
        if (file is null) return;
        GetWindowThreadProcessId((nint)(int)app.Hwnd, out var pid);
        if (pid == 0) throw new InvalidOperationException("Cannot determine the owned Excel process.");
        using var process = Process.GetProcessById((int)pid);
        var identity = new WorkerHost.ExcelIdentity((int)pid, process.StartTime.ToUniversalTime().Ticks);
        // The parent must never observe a partially written identity during cancellation.
        File.WriteAllText(file + ".tmp", JsonSerializer.Serialize(identity));
        File.Move(file + ".tmp", file, true);
    }
}

public sealed record SheetRepeat(string TemplateSheet, string Source, string NameTemplate = "{{Name}}");
