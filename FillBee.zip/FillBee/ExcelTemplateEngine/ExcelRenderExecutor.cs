namespace FillBee;

/// <summary>Adapts ExcelTemplateRenderer for RenderQueue. Each job uses its configured Worker isolation.</summary>
public sealed class ExcelRenderExecutor : IRenderExecutor
{
    private readonly ExcelTemplateRenderer _renderer = new();
    public Task<RenderResult> ExecuteAsync(RenderJob job, CancellationToken cancellationToken)
        => _renderer.RenderAsync(job.TemplatePath, job.OutputPath, job.Model, job.Options, cancellationToken);
    public ValueTask DisposeAsync() => ValueTask.CompletedTask;
}
