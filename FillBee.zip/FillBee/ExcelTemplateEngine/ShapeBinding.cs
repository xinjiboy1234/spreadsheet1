namespace FillBee;
public sealed record WordArtValue(string Text);
public sealed record ChartValue(string? Title = null, string? SourceRange = null);
internal static class ShapeBinding
{
 public static void Apply(object worksheet,BindingScope scope)
 {
  dynamic sheet=worksheet;object? shapes=null;
  try{shapes=sheet.Shapes;int count=((dynamic)shapes).Count;for(int i=count;i>=1;i--){object? shape=null;try{shape=((dynamic)shapes).Item(i);string name=((dynamic)shape).Name;if(!name.StartsWith("tpl:",StringComparison.Ordinal))continue;var parts=name.Split(':',3);if(parts.Length!=3)throw new FormatException($"Invalid shape name {name}.");var value=ValueResolver.Resolve(scope,parts[2]);if(value is null)continue;
   if(value is System.Collections.Generic.Dictionary<string,object?> mapped){if(parts[1]=="image")value=new ImageValue(mapped.GetValueOrDefault("FilePath") as string,mapped.GetValueOrDefault("Data") is string bytes?Convert.FromBase64String(bytes):null,mapped.GetValueOrDefault("Fit") is decimal fit?(ImageFit)(int)fit:ImageFit.Contain);else if(parts[1]=="wordart")value=new WordArtValue(Convert.ToString(mapped.GetValueOrDefault("Text"))??"");else if(parts[1]=="chart")value=new ChartValue(mapped.GetValueOrDefault("Title") as string,mapped.GetValueOrDefault("SourceRange") as string);}
   switch(parts[1]){
    case "wordart":object? effect=null;try{effect=((dynamic)shape).TextEffect;((dynamic)effect).Text=value is WordArtValue art?art.Text:Convert.ToString(value)??"";}finally{ComAccess.Release(effect);}break;
    case "image":if(value is not ImageValue image)throw new InvalidOperationException($"{parts[2]} must be ImageValue.");InsertImage(shapes,shape,image);break;
    case "chart":if(value is not ChartValue data)throw new InvalidOperationException($"{parts[2]} must be ChartValue.");object? chart=null,title=null,range=null;try{chart=((dynamic)shape).Chart;if(data.Title is not null){((dynamic)chart).HasTitle=true;title=((dynamic)chart).ChartTitle;((dynamic)title).Text=data.Title;}if(data.SourceRange is not null){range=sheet.Range[data.SourceRange];((dynamic)chart).SetSourceData(range);}}finally{ComAccess.Release(range);ComAccess.Release(title);ComAccess.Release(chart);}break;
    default:throw new NotSupportedException($"Unsupported shape binding {parts[1]}.");
   }
  }finally{ComAccess.Release(shape);}}}finally{ComAccess.Release(shapes);}
 }
 private static void InsertImage(dynamic shapes,dynamic placeholder,ImageValue image)
 {
  string? temporary=null;object? picture=null;
  try{var path=image.FilePath;if(image.Data is not null){temporary=Path.Combine(Path.GetTempPath(),$"fillbee-image-{Guid.NewGuid():N}.png");File.WriteAllBytes(temporary,image.Data);path=temporary;}if(path is null||!File.Exists(path))throw new FileNotFoundException("Image file does not exist.",path);
   float left=Convert.ToSingle(placeholder.Left),top=Convert.ToSingle(placeholder.Top),width=Convert.ToSingle(placeholder.Width),height=Convert.ToSingle(placeholder.Height);
   picture=shapes.AddPicture(Path.GetFullPath(path),0,-1,left,top,-1,-1);dynamic p=picture;float naturalWidth=Convert.ToSingle(p.Width),naturalHeight=Convert.ToSingle(p.Height);
   p.LockAspectRatio=0;
   if(image.Fit==ImageFit.Stretch){p.Width=width;p.Height=height;}else if(image.Fit==ImageFit.Contain){float ratio=Math.Min(width/naturalWidth,height/naturalHeight);p.Width=naturalWidth*ratio;p.Height=naturalHeight*ratio;p.Left=left+(width-(float)p.Width)/2;p.Top=top+(height-(float)p.Height)/2;}else{float ratio=Math.Max(width/naturalWidth,height/naturalHeight);p.Width=naturalWidth*ratio;p.Height=naturalHeight*ratio;object? format=null,crop=null;try{format=p.PictureFormat;crop=((dynamic)format).Crop;((dynamic)crop).ShapeWidth=width;((dynamic)crop).ShapeHeight=height;((dynamic)crop).PictureWidth=naturalWidth*ratio;((dynamic)crop).PictureHeight=naturalHeight*ratio;((dynamic)crop).PictureOffsetX=0;((dynamic)crop).PictureOffsetY=0;}finally{ComAccess.Release(crop);ComAccess.Release(format);}}
   p.Rotation=placeholder.Rotation;p.Placement=placeholder.Placement;string name=placeholder.Name;placeholder.Delete();p.Name=name;
  }finally{ComAccess.Release(picture);if(temporary is not null)File.Delete(temporary);}
 }
}

