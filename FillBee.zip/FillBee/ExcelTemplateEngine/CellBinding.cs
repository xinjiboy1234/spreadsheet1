using System.Globalization;
namespace FillBee;
internal static class CellBinding
{
 public static void Apply(object used,object? values,object model,RenderOptions options,TemplateFormatters formatters)
 {
  if(values is object[,] grid){for(int r=grid.GetLowerBound(0);r<=grid.GetUpperBound(0);r++)for(int c=grid.GetLowerBound(1);c<=grid.GetUpperBound(1);c++)Bind(used,r,c,grid[r,c],model,options,formatters);}
  else Bind(used,1,1,values,model,options,formatters);
 }
 private static void Bind(dynamic used,int row,int column,object? value,object model,RenderOptions options,TemplateFormatters formatters)
 {
  if(value is not string text||!text.Contains("{{"))return;
  object? cells=null,cell=null;
  try{
   cells=used.Cells;cell=((dynamic)cells)[row,column];
   if((bool)((dynamic)cell).HasFormula)return;
   var tokens=TemplateSyntax.Scan(text).ToArray();
   if(tokens.Any(t=>t.Kind!="value"))throw new FormatException("Structural directives require region rendering.");
   var scope=new BindingScope(model,model,null);
   if(tokens.Length==1&&tokens[0].Start==0&&tokens[0].Length==text.Length&&!tokens[0].Expression.Contains('|')){
    var resolved=ValueResolver.Resolve(scope,tokens[0].Expression);
    if(resolved is null&&options.MissingValue==MissingValueBehavior.Throw)throw new KeyNotFoundException(tokens[0].Expression);
    ((dynamic)cell).Value2=resolved is DateTime date?date.ToOADate():resolved;
   }else ((dynamic)cell).Value2=TemplateSyntax.Expand(text,scope,options,formatters);
  }finally{Release(cell);Release(cells);}
 }
 private static void Release(object? value){if(OperatingSystem.IsWindows()&&value is not null&&System.Runtime.InteropServices.Marshal.IsComObject(value))System.Runtime.InteropServices.Marshal.ReleaseComObject(value);}
}
