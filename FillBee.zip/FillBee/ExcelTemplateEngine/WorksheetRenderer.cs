using System.Collections;
using System.Runtime.InteropServices;
namespace FillBee;
internal static class ComAccess
{
 public static void Release(object? o){if(OperatingSystem.IsWindows()&&o is not null&&Marshal.IsComObject(o))Marshal.ReleaseComObject(o);}
}
internal sealed class WorksheetRenderer(RenderOptions options,TemplateFormatters formatters,CancellationToken cancellation)
{
 public void Render(object worksheet,BindingScope scope)
 {
  HorizontalRendering.Apply(worksheet,scope,options,formatters,cancellation);
  dynamic sheet=worksheet;object? used=null,rows=null,columns=null;
  try{used=sheet.UsedRange;rows=((dynamic)used).Rows;columns=((dynamic)used).Columns;int first=((dynamic)used).Row;int last=first+(int)((dynamic)rows).Count-1;int col=((dynamic)used).Column;int end=col+(int)((dynamic)columns).Count-1;RenderRows(worksheet,first,last,col,end,scope);}
  finally{ComAccess.Release(columns);ComAccess.Release(rows);ComAccess.Release(used);}
 }
 private int RenderRows(object worksheet,int first,int last,int col,int end,BindingScope scope)
 {
  dynamic sheet=worksheet;
  for(int r=first;r<=last;r++){
   cancellation.ThrowIfCancellationRequested();
   string? directive=null;
   for(int c=col;c<=end;c++){var text=Read(worksheet,r,c);if(text is string s&&s.Trim().StartsWith("{{#")){directive=s.Trim();break;}}
   if(directive is null){for(int c=col;c<=end;c++)Bind(worksheet,r,c,scope);continue;}
   var token=TemplateSyntax.Scan(directive).Single();var expression=token.Expression;var isEach=expression.StartsWith("#each ");var isIf=expression.StartsWith("#if ");if(!isEach&&!isIf)throw new FormatException($"Unknown directive {expression}.");
   if(expression.Contains("direction="))throw new NotSupportedException("Horizontal region rendering is not yet implemented.");
   int depth=1,close=r;
   while(++close<=last){for(int c=col;c<=end;c++){if(Read(worksheet,close,c) is not string text)continue;foreach(var t in TemplateSyntax.Scan(text)){if(t.Kind=="open")depth++;if(t.Kind=="close")depth--;}}if(depth==0)break;}
   if(depth!=0)throw new FormatException($"Unclosed block at row {r}.");
   var path=expression[(isEach?6:4)..].Trim();var value=ValueResolver.Resolve(scope,path);
   var items=isEach?(value is IEnumerable sequence&&value is not string?sequence.Cast<object?>().ToArray():value is null?[]:throw new InvalidOperationException($"{path} is not a collection.")):(value is true?new[]{scope.Current}:Array.Empty<object?>());
   int height=close-r-1;
   // Copy all original bodies before rendering any nested region.
   if(height>0)for(int i=1;i<items.Length;i++){object? source=null,destination=null;try{source=sheet.Range[$"{r+1}:{close-1}"];destination=sheet.Range[$"{r+1+i*height}:{r+(i+1)*height}"];((dynamic)destination).Insert(-4121);ComAccess.Release(destination);destination=sheet.Range[$"{r+1+i*height}:{r+(i+1)*height}"];((dynamic)source).Copy(destination);}finally{ComAccess.Release(destination);ComAccess.Release(source);}}
   int expanded=height*items.Length;
   DeleteRows(worksheet,close+Math.Max(0,items.Length-1)*height,close+Math.Max(0,items.Length-1)*height); // closing marker shifted by inserted bodies
   if(items.Length==0&&height>0)DeleteRows(worksheet,r+1,r+height);
   DeleteRows(worksheet,r,r);
   int position=r,total=0;
   for(int i=0;i<items.Length;i++){var child=isEach?new BindingScope(items[i],scope.Root,scope,i+1,items.Length):scope;int rendered=RenderRows(worksheet,position,position+height-1,col,end,child);position+=rendered;total+=rendered;}
   last+=total-(height+2);r=position-1;
  }
  return last-first+1;
 }
 private static void DeleteRows(dynamic sheet,int first,int last){object? range=null;try{range=sheet.Range[$"{first}:{last}"];((dynamic)range).Delete();}finally{ComAccess.Release(range);}}
 private static object? Read(dynamic sheet,int row,int column){object? cells=null,cell=null;try{cells=sheet.Cells;cell=((dynamic)cells)[row,column];return ((dynamic)cell).Value2;}finally{ComAccess.Release(cell);ComAccess.Release(cells);}}
 private void Bind(dynamic sheet,int row,int column,BindingScope scope){object? cells=null,cell=null;try{cells=sheet.Cells;cell=((dynamic)cells)[row,column];if((bool)((dynamic)cell).HasFormula)return;if(((dynamic)cell).Value2 is not string text||!text.Contains("{{"))return;((dynamic)cell).Value2=TemplateSyntax.Expand(text,scope,options,formatters);}finally{ComAccess.Release(cell);ComAccess.Release(cells);}}
}



