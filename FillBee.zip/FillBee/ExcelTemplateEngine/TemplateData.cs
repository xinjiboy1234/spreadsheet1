using System.Collections;
using System.Globalization;
using System.Reflection;
using System.Text.RegularExpressions;

namespace FillBee;

public sealed record ImageValue(string? FilePath = null, byte[]? Data = null, ImageFit Fit = ImageFit.Contain)
{
    public static ImageValue FromFile(string path, ImageFit fit = ImageFit.Contain) => new(path, null, fit);
    public static ImageValue FromBytes(byte[] data, ImageFit fit = ImageFit.Contain) => new(null, data, fit);
}
public enum ImageFit { Contain, Cover, Stretch }
public interface ITemplateFormatter { string Name { get; } object? Format(object? value, string? argument); }
public sealed class TemplateFormatters
{
    private readonly Dictionary<string, ITemplateFormatter> _items = new(StringComparer.OrdinalIgnoreCase);
    public TemplateFormatters() { Register(new DelegateFormatter("number", (v,a) => v is null ? "" : Convert.ToDecimal(v, CultureInfo.InvariantCulture).ToString(a ?? "#,##0.##", CultureInfo.CurrentCulture))); Register(new DelegateFormatter("date", (v,a) => v is null ? "" : Convert.ToDateTime(v, CultureInfo.InvariantCulture).ToString(a ?? "yyyy-MM-dd", CultureInfo.CurrentCulture))); Register(new DelegateFormatter("default", (v,a) => v ?? a ?? "")); }
    public void Register(ITemplateFormatter formatter) => _items[formatter.Name] = formatter;
    public bool TryFormat(string name, object? value, string? arg, out object? result) { if (_items.TryGetValue(name, out var f)) { result = f.Format(value,arg); return true; } result=null; return false; }
    private sealed record DelegateFormatter(string Name, Func<object?,string?,object?> Callback) : ITemplateFormatter { public object? Format(object? value,string? argument)=>Callback(value,argument); }
}
internal sealed record BindingScope(object? Current, object? Root, BindingScope? Parent, int Index=0, int Count=0);
internal static class ValueResolver
{
    public static object? Resolve(BindingScope scope, string path)
    {
        if(path=="@index") return scope.Index; if(path=="@count") return scope.Count;
        if(path.StartsWith("@root.",StringComparison.OrdinalIgnoreCase)) return Walk(scope.Root,path[6..]);
        if(path.StartsWith("@parent.",StringComparison.OrdinalIgnoreCase)) return Walk(scope.Parent?.Current,path[8..]);
        return Walk(scope.Current,path);
    }
    private static object? Walk(object? obj,string path) { foreach(var part in path.Split('.',StringSplitOptions.RemoveEmptyEntries)) { if(obj is null)return null; if(obj is IDictionary d) { var key=d.Keys.Cast<object>().FirstOrDefault(k=>string.Equals(Convert.ToString(k),part,StringComparison.OrdinalIgnoreCase)); obj=key is null?null:d[key]; } else obj=obj.GetType().GetProperty(part,BindingFlags.Instance|BindingFlags.Public|BindingFlags.IgnoreCase)?.GetValue(obj); } return obj; }
}
