using System.Diagnostics;
using System.Text.Json;
namespace FillBee;
internal sealed record WorkerRequest(string Template,string Output,JsonElement Model,RenderOptions Options,string OwnerFile);
internal sealed record WorkerResponse(RenderResult? Result,string? Error);
internal static class WorkerHost
{
 public static async Task<int> Main(string[] args)
 {
  if(args.Length!=3||args[0]!="--fillbee-worker")return 2;
  WorkerResponse response;
  try{var request=JsonSerializer.Deserialize<WorkerRequest>(await File.ReadAllTextAsync(args[1]))!;Environment.SetEnvironmentVariable("FILLBEE_OWNER_FILE",request.OwnerFile);using var cancellation=new CancellationTokenSource();await using var poll=new Timer(_=>{if(File.Exists(request.OwnerFile+".cancel"))cancellation.Cancel();},null,0,50);var model=Normalize(request.Model)!;var result=await new ExcelTemplateRenderer().RenderAsync(request.Template,request.Output,model,request.Options with{UseWorker=false},cancellation.Token);response=new(result,null);}
  catch(Exception ex){response=new(null,ex.ToString());}
  await File.WriteAllTextAsync(args[2],JsonSerializer.Serialize(response));return response.Error is null?0:1;
 }
 private static object? Normalize(JsonElement value)=>value.ValueKind switch{JsonValueKind.Object=>value.EnumerateObject().ToDictionary(p=>p.Name,p=>Normalize(p.Value)),JsonValueKind.Array=>value.EnumerateArray().Select(Normalize).ToArray(),JsonValueKind.String=>value.GetString(),JsonValueKind.Number=>value.GetDecimal(),JsonValueKind.True=>true,JsonValueKind.False=>false,_=>null};
 public static async Task<RenderResult> Execute(string template,string output,object model,RenderOptions options,CancellationToken cancellation)
 {
  var folder=Path.Combine(Path.GetTempPath(),"FillBee",Guid.NewGuid().ToString("N"));Directory.CreateDirectory(folder);var request=Path.Combine(folder,"request.json");var response=Path.Combine(folder,"response.json");var owner=Path.Combine(folder,"excel.json");var staged=Path.Combine(Path.GetDirectoryName(Path.GetFullPath(output))!, $".fillbee-worker-{Guid.NewGuid():N}{Path.GetExtension(output)}");
  using var timeout=CancellationTokenSource.CreateLinkedTokenSource(cancellation);timeout.CancelAfter(options.Timeout??TimeSpan.FromMinutes(3));
  using var process=new Process{StartInfo=new ProcessStartInfo("dotnet"){UseShellExecute=false,CreateNoWindow=true}};
  var assembly=typeof(WorkerHost).Assembly.Location;process.StartInfo.ArgumentList.Add(assembly);process.StartInfo.ArgumentList.Add("--fillbee-worker");process.StartInfo.ArgumentList.Add(request);process.StartInfo.ArgumentList.Add(response);
  try{await File.WriteAllTextAsync(request,JsonSerializer.Serialize(new WorkerRequest(Path.GetFullPath(template),staged,JsonSerializer.SerializeToElement(model),options,owner)),cancellation);process.Start();try{await process.WaitForExitAsync(timeout.Token);}catch(OperationCanceledException){await StopWorkerAsync(process,owner);if(cancellation.IsCancellationRequested)throw;throw new TimeoutException("Excel rendering exceeded the configured timeout.");}
   var result=JsonSerializer.Deserialize<WorkerResponse>(await File.ReadAllTextAsync(response,cancellation))!;if(result.Error is not null)throw new InvalidOperationException(result.Error);cancellation.ThrowIfCancellationRequested();Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(output))!);File.Move(staged,output,true);return result.Result! with{OutputPath=output};
  }finally{CleanupExcel(owner);if(File.Exists(staged))File.Delete(staged);Directory.Delete(folder,true);}
 }
 private static async Task StopWorkerAsync(Process process,string owner)
 {
  // COM activation may create Excel before returning its HWND. Signal cancellation first,
  // and allow ownership registration before forcibly killing the worker.
  await File.WriteAllTextAsync(owner+".cancel", "cancel");
  var grace=Stopwatch.StartNew();
  while(!process.HasExited&&!File.Exists(owner)&&grace.Elapsed<TimeSpan.FromSeconds(15))
   await Task.Delay(50);
  if(!process.HasExited)process.Kill(true);
  await process.WaitForExitAsync();
  CleanupExcel(owner);
 }
 private static void CleanupExcel(string file){try{if(!File.Exists(file))return;var identity=JsonSerializer.Deserialize<ExcelIdentity>(File.ReadAllText(file))!;using var excel=Process.GetProcessById(identity.Pid);if(excel.ProcessName.Equals("EXCEL",StringComparison.OrdinalIgnoreCase)&&excel.StartTime.ToUniversalTime().Ticks==identity.StartTicks)excel.Kill();}catch(ArgumentException){}catch(InvalidOperationException){} }
 internal sealed record ExcelIdentity(int Pid,long StartTicks);
}


