using System.Diagnostics;
namespace FillBee;
/// <summary>Excel COM template renderer. All COM operations execute on one STA thread.</summary>
public sealed class ExcelTemplateRenderer : IExcelTemplateRenderer
{
 public TemplateFormatters Formatters { get; }=new();
 public RenderResult Render(string templatePath,string outputPath,object model,RenderOptions? options=null)=>RenderAsync(templatePath,outputPath,model,options).GetAwaiter().GetResult();
 public async Task<RenderResult> RenderAsync(string templatePath,string outputPath,object model,RenderOptions? options=null,CancellationToken cancellationToken=default)
 {
  ArgumentException.ThrowIfNullOrWhiteSpace(templatePath);ArgumentException.ThrowIfNullOrWhiteSpace(outputPath);ArgumentNullException.ThrowIfNull(model);
  options??=new();if(options.UseWorker)return await WorkerHost.Execute(templatePath,outputPath,model,options,cancellationToken);templatePath=Path.GetFullPath(templatePath);outputPath=Path.GetFullPath(outputPath);
  if(templatePath.Equals(outputPath,StringComparison.OrdinalIgnoreCase))throw new ArgumentException("Output must not overwrite the template.");
  if(!File.Exists(templatePath))throw new FileNotFoundException("Template file not found.",templatePath);
  if(options.ValidateBeforeRender){var validation=Validate(templatePath);if(!validation.IsValid)throw new InvalidDataException(string.Join(Environment.NewLine,validation.Diagnostics.Select(d=>$"{d.Code} {d.SheetName}!{d.CellAddress}: {d.Message}")));}
  if(!options.PreserveMacros&&Path.GetExtension(outputPath).Equals(".xlsm",StringComparison.OrdinalIgnoreCase))throw new ArgumentException("PreserveMacros=false requires .xlsx output.");
  if(options.PreserveMacros&&Path.GetExtension(templatePath).Equals(".xlsm",StringComparison.OrdinalIgnoreCase)&&!Path.GetExtension(outputPath).Equals(".xlsm",StringComparison.OrdinalIgnoreCase))throw new ArgumentException("Macro templates require .xlsm output when PreserveMacros=true.");
  cancellationToken.ThrowIfCancellationRequested();Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
  string temporary=Path.Combine(Path.GetDirectoryName(outputPath)!, $".fillbee-{Guid.NewGuid():N}{Path.GetExtension(outputPath)}");var timer=Stopwatch.StartNew();
  try{
   await StaRunner.Run(()=>{
    if(!OperatingSystem.IsWindows())throw new PlatformNotSupportedException("Excel requires Windows.");
    object? application=null,books=null,book=null,sheets=null;
    try{
     application=Activator.CreateInstance(Type.GetTypeFromProgID("Excel.Application")??throw new InvalidOperationException("Excel is not registered."));dynamic app=application!;
     ExcelOwnership.Record(app);cancellationToken.ThrowIfCancellationRequested();app.Visible=false;app.DisplayAlerts=false;app.AutomationSecurity=3;app.EnableEvents=false;
     books=app.Workbooks;book=((dynamic)books).Open(templatePath,options.UpdateExternalLinks?3:0,true);sheets=((dynamic)book).Worksheets;
     var contexts=SheetExpansion.Apply(sheets!,model,options,Formatters);int count=((dynamic)sheets).Count;
     for(int i=1;i<=count;i++){cancellationToken.ThrowIfCancellationRequested();object? sheet=null;try{sheet=((dynamic)sheets).Item(i);var scope=contexts.TryGetValue((string)((dynamic)sheet).Name,out var sheetScope)?sheetScope:new BindingScope(model,model,null);new WorksheetRenderer(options,Formatters,cancellationToken).Render(sheet!,scope);ShapeBinding.Apply(sheet!,scope);}finally{ComAccess.Release(sheet);}}
     if(options.RecalculateFormulas)app.CalculateFull();cancellationToken.ThrowIfCancellationRequested();((dynamic)book).SaveAs(temporary,Path.GetExtension(outputPath).Equals(".xlsm",StringComparison.OrdinalIgnoreCase)?52:51);return true;
    }finally{try{if(book is not null)((dynamic)book).Close(false);}finally{try{if(application is not null)((dynamic)application).Quit();}finally{ComAccess.Release(sheets);ComAccess.Release(book);ComAccess.Release(books);ComAccess.Release(application);}}}
   }).ConfigureAwait(false);
   cancellationToken.ThrowIfCancellationRequested();File.Move(temporary,outputPath,true);return new(true,outputPath,timer.Elapsed,[]);
  }finally{if(File.Exists(temporary))File.Delete(temporary);}
 }
 public TemplateValidationResult Validate(string templatePath)=>WorkbookValidation.Validate(templatePath);
}



