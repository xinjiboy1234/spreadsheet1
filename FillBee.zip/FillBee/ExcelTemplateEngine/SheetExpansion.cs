using System.Collections;
using System.Text.RegularExpressions;
namespace FillBee;
internal static class SheetExpansion
{
 public static Dictionary<string,BindingScope> Apply(object worksheets,object model,RenderOptions options,TemplateFormatters formatters)
 {
  var result=new Dictionary<string,BindingScope>(StringComparer.OrdinalIgnoreCase);dynamic sheets=worksheets;var root=new BindingScope(model,model,null);
  foreach(var repeat in options.SheetRepeats??[]){object? template=null;try{template=sheets.Item(repeat.TemplateSheet);var value=ValueResolver.Resolve(root,repeat.Source);if(value is not IEnumerable sequence||value is string)throw new InvalidOperationException($"{repeat.Source} must be a collection.");var items=sequence.Cast<object?>().ToArray();for(int i=0;i<items.Length;i++){var scope=new BindingScope(items[i],model,root,i+1,items.Length);object? tail=null,copy=null;try{tail=sheets.Item((int)sheets.Count);((dynamic)template).Copy(Type.Missing,tail);copy=sheets.Item((int)sheets.Count);var proposed=TemplateSyntax.Expand(repeat.NameTemplate,scope,options,formatters);var baseName=Regex.Replace(proposed,@"[\[\]:*?/\\]","_").Trim().Trim('\'');if(baseName.Length==0)baseName="Sheet";baseName=baseName[..Math.Min(31,baseName.Length)];var used=new HashSet<string>(StringComparer.OrdinalIgnoreCase);for(int j=1;j<=(int)sheets.Count;j++){object? item=null;try{item=sheets.Item(j);used.Add((string)((dynamic)item).Name);}finally{ComAccess.Release(item);}}var name=baseName;for(int suffix=2;used.Contains(name);suffix++){var ending=$" ({suffix})";name=baseName[..Math.Min(baseName.Length,31-ending.Length)]+ending;}((dynamic)copy).Name=name;result.Add(name,scope);}finally{ComAccess.Release(copy);ComAccess.Release(tail);}}((dynamic)template).Delete();}finally{ComAccess.Release(template);}}
  return result;
 }
}
