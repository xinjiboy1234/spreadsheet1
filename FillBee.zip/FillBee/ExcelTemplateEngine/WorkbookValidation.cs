using System.IO.Compression;
using System.Xml.Linq;
namespace FillBee;
internal static class WorkbookValidation
{
 private static readonly XNamespace Main="http://schemas.openxmlformats.org/spreadsheetml/2006/main";
 public static TemplateValidationResult Validate(string path)
 {
  var errors=new List<TemplateDiagnostic>();
  if(!File.Exists(path))return new(false,[new("TPL0001","Template file does not exist.")]);
  if(!new[]{".xlsx",".xlsm"}.Contains(Path.GetExtension(path),StringComparer.OrdinalIgnoreCase))return new(false,[new("TPL0002","Only .xlsx and .xlsm templates are supported.")]);
  try{
   using var zip=ZipFile.OpenRead(path);
   XDocument Read(string name){using var stream=(zip.GetEntry(name)??throw new InvalidDataException($"Missing workbook part {name}.")).Open();return XDocument.Load(stream);}
   var workbook=Read("xl/workbook.xml");
   var shared=zip.GetEntry("xl/sharedStrings.xml") is null?Array.Empty<string>():Read("xl/sharedStrings.xml").Descendants(Main+"si").Select(x=>string.Concat(x.Descendants(Main+"t").Select(t=>t.Value))).ToArray();
   XNamespace rel="http://schemas.openxmlformats.org/package/2006/relationships";
   XNamespace docRel="http://schemas.openxmlformats.org/officeDocument/2006/relationships";
   var links=Read("xl/_rels/workbook.xml.rels").Descendants(rel+"Relationship").ToDictionary(x=>(string)x.Attribute("Id")!,x=>(string)x.Attribute("Target")!);
   foreach(var sheet in workbook.Descendants(Main+"sheet")){
    var name=(string?)sheet.Attribute("name")??"";
    var id=(string?)sheet.Attribute(docRel+"id");
    if(id is null||!links.TryGetValue(id,out var target)){errors.Add(new("TPL0003","Worksheet relationship is missing.",name));continue;}
    var part=new Uri(new Uri("http://workbook/xl/workbook.xml"),target).AbsolutePath.TrimStart('/');
    var xml=Read(part);var stack=new Stack<(string Kind,string Address)>();
    foreach(var cell in xml.Descendants(Main+"c")){
     if(cell.Element(Main+"f") is not null)continue;
     var address=(string?)cell.Attribute("r");var kind=(string?)cell.Attribute("t");
     string text;
     if(kind=="s"){
      if(!int.TryParse(cell.Element(Main+"v")?.Value,out var index)||index<0||index>=shared.Length){errors.Add(new("TPL0003","Invalid shared string reference.",name,address));continue;}
      text=shared[index];
     }else text=kind=="inlineStr"?string.Concat(cell.Descendants(Main+"t").Select(t=>t.Value)):cell.Element(Main+"v")?.Value??"";
     foreach(var token in TemplateSyntax.Scan(text)){
      var exp=token.Expression;
      if(token.Kind=="open"){
       var directive=exp.Split(' ',StringSplitOptions.RemoveEmptyEntries)[0];
       if(directive is not ("#each" or "#if")){errors.Add(new("TPL1002",$"Unknown directive '{exp}'.",name,address));continue;}
       if(exp.Length==directive.Length){errors.Add(new("TPL1002","Directive requires a data path.",name,address));continue;}
       if(text.Trim()!="{{"+exp+"}}")errors.Add(new("TPL1002","Block marker must occupy its own cell.",name,address));
       stack.Push((directive[1..],address??""));
      }else if(token.Kind=="close"){
       if(stack.Count==0)errors.Add(new("TPL1001",$"Unexpected closing directive '{exp}'.",name,address));
       else{var open=stack.Pop();if(exp!="/"+open.Kind)errors.Add(new("TPL1001",$"Expected /{open.Kind} for block at {open.Address}.",name,address));}
      }
     }
    }
    foreach(var open in stack)errors.Add(new("TPL1001",$"Unclosed {open.Kind} block.",name,open.Address));
   }
  }catch(Exception ex)when(ex is IOException or InvalidDataException or System.Xml.XmlException or ArgumentException){errors.Add(new("TPL0003",$"Invalid workbook: {ex.Message}"));}
  return new(errors.Count==0,errors);
 }
}
