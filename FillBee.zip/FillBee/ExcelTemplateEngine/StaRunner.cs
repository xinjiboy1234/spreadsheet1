namespace FillBee;
internal static class StaRunner
{
 public static Task<T> Run<T>(Func<T> action)
 {
  if(!OperatingSystem.IsWindows())throw new PlatformNotSupportedException();
  var completion=new TaskCompletionSource<T>(TaskCreationOptions.RunContinuationsAsynchronously);
  var thread=new Thread(()=>{try{completion.TrySetResult(action());}catch(Exception ex){completion.TrySetException(ex);}}){IsBackground=true,Name="FillBee Excel STA"};thread.SetApartmentState(ApartmentState.STA);thread.Start();return completion.Task;
 }
}
