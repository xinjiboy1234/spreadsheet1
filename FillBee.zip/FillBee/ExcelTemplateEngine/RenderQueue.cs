using System.Threading.Channels;

namespace FillBee;

public sealed record RenderJob(string TemplatePath, string OutputPath, object Model, RenderOptions? Options = null);
public sealed record RenderOptions(TimeSpan? Timeout = null, bool RecalculateFormulas = true, bool PreserveMacros = true,
    bool UpdateExternalLinks = false, MissingValueBehavior MissingValue = MissingValueBehavior.Throw,
    EmptyCollectionBehavior EmptyCollection = EmptyCollectionBehavior.RemoveBlock, bool ValidateBeforeRender = true, bool UseWorker = true, IReadOnlyList<SheetRepeat>? SheetRepeats = null);
public enum MissingValueBehavior { Throw, Empty }
public enum EmptyCollectionBehavior { RemoveBlock, KeepTemplateRow }
public sealed record TemplateDiagnostic(string Code, string Message, string? SheetName = null, string? CellAddress = null, string? ShapeName = null);
public sealed record RenderResult(bool Success, string? OutputPath, TimeSpan Duration, IReadOnlyList<TemplateDiagnostic> Diagnostics);
public sealed record TemplateValidationResult(bool IsValid, IReadOnlyList<TemplateDiagnostic> Diagnostics);

public interface IExcelTemplateRenderer
{
    RenderResult Render(string templatePath, string outputPath, object model, RenderOptions? options = null);
    Task<RenderResult> RenderAsync(string templatePath, string outputPath, object model, RenderOptions? options = null, CancellationToken cancellationToken = default);
    TemplateValidationResult Validate(string templatePath);
}

public interface IRenderExecutor : IAsyncDisposable
{
    Task<RenderResult> ExecuteAsync(RenderJob job, CancellationToken cancellationToken);
}

/// <summary>
/// Bounded queue. Defaults to serial execution; maxConcurrency bounds active jobs.
/// DisposeAsync stops accepting new work and drains accepted jobs before disposing the executor.
/// With multiple execution slots, completion order is not guaranteed.
/// </summary>
public sealed class RenderQueue : IAsyncDisposable
{
    private readonly Channel<Work> _channel;
    private readonly IRenderExecutor _executor;
    private readonly Task _pump;
    private readonly object _disposeGate = new();
    private Task? _disposeTask;
    private int _disposed;

    public RenderQueue(IRenderExecutor executor, int capacity = 32, int maxConcurrency = 1)
    {
        ArgumentNullException.ThrowIfNull(executor);
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(capacity);
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(maxConcurrency);
        _executor = executor;
        _channel = Channel.CreateBounded<Work>(new BoundedChannelOptions(capacity)
        {
            FullMode = BoundedChannelFullMode.Wait,
            SingleReader = maxConcurrency == 1,
            AllowSynchronousContinuations = false
        });
        _pump = Task.WhenAll(Enumerable.Range(0, maxConcurrency).Select(_ => PumpAsync()));
    }

    public async Task<RenderResult> EnqueueAsync(RenderJob job, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(job);
        ObjectDisposedException.ThrowIf(Volatile.Read(ref _disposed) != 0, this);
        // Validate outside the pump so a malformed timeout cannot terminate a consumer.
        if (job.Options?.Timeout is { } timeout &&
            (timeout < TimeSpan.Zero && timeout != Timeout.InfiniteTimeSpan || timeout.TotalMilliseconds > uint.MaxValue - 1))
            throw new ArgumentOutOfRangeException(nameof(job), "Timeout must be nonnegative or InfiniteTimeSpan, and fit CancellationTokenSource.CancelAfter.");
        var work = new Work(job, cancellationToken);
        try { await _channel.Writer.WriteAsync(work, cancellationToken).ConfigureAwait(false); }
        catch (ChannelClosedException) { throw new ObjectDisposedException(nameof(RenderQueue)); }
        return await work.Result.Task.WaitAsync(cancellationToken).ConfigureAwait(false);
    }

    private async Task PumpAsync()
    {
        await foreach (var work in _channel.Reader.ReadAllAsync().ConfigureAwait(false))
        {
            if (work.CancellationToken.IsCancellationRequested)
            {
                work.Result.TrySetCanceled(work.CancellationToken);
                continue;
            }
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(work.CancellationToken);
            if (work.Job.Options?.Timeout is { } value) timeout.CancelAfter(value);
            try
            {
                timeout.Token.ThrowIfCancellationRequested();
                var result = await _executor.ExecuteAsync(work.Job, timeout.Token).ConfigureAwait(false);
                timeout.Token.ThrowIfCancellationRequested();
                work.Result.TrySetResult(result);
            }
            catch (OperationCanceledException) when (work.CancellationToken.IsCancellationRequested)
            {
                work.Result.TrySetCanceled(work.CancellationToken);
            }
            catch (OperationCanceledException) when (timeout.IsCancellationRequested)
            {
                work.Result.TrySetException(new TimeoutException("Queued rendering exceeded its execution timeout."));
            }
            catch (Exception ex) { work.Result.TrySetException(ex); }
        }
    }

    public ValueTask DisposeAsync()
    {
        lock (_disposeGate) return new ValueTask(_disposeTask ??= DisposeCoreAsync());
    }

    private async Task DisposeCoreAsync()
    {
        Interlocked.Exchange(ref _disposed, 1);
        _channel.Writer.TryComplete();
        try { await _pump.ConfigureAwait(false); }
        finally { await _executor.DisposeAsync().ConfigureAwait(false); }
    }

    private sealed record Work(RenderJob Job, CancellationToken CancellationToken)
    {
        public TaskCompletionSource<RenderResult> Result { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
    }
}
