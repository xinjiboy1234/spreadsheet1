我建议将这个组件设计为一个 基于 C# + Excel COM 的通用 Excel 模板渲染引擎，定位为可复用的基础组件，而不是简单的 Excel 单元格替换工具。

核心设计理念是：

模板负责布局，数据对象负责内容，渲染引擎负责循环、扩展、填充和 Excel 对象操作。

这样可以保留 Excel 原生的复杂能力，包括单元格样式、公式、合并单元格、图片、艺术字、图表、打印设置、分页和多 Sheet，同时让调用方只需要传入一个 C# 对象，就能生成完整报表。

下面按可落地开发的产品设计文档（PRD + 技术概要设计）的形式组织，重点解决五个问题：

1. 模板语法简单：普通用户能直接在 Excel 中设计模板。
2. 数据结构统一：支持对象、集合、嵌套对象、图片和艺术字等复杂内容。
3. 循环能力完整：支持横向、纵向、嵌套循环、动态 Sheet。
4. Excel 原生特性保留：尽量通过 Excel COM 自身完成复制、插入、填充。
5. 进程与资源可控：Excel 实例独立、执行线程固定、异常可恢复、不遗留 Excel.exe。

# ExcelTemplateEngine 产品设计文档

PRD / 技术设计

设计版本 v1.0 · C# / .NET / Excel COM

## 一、产品定位与目标

### 1.1 产品名称

ExcelTemplateEngine（ETE）

一个基于 Microsoft Excel COM Automation 的通用模板解析与渲染组件。

### 1.2 产品目标

调用方通过以下三个输入完成 Excel 文档生成：

生成保留 Excel 原生能力的 .xlsx / .xlsm 等工作簿

典型调用方式：

```
var result = renderer.Render(
    templatePath: "销售报表模板.xlsx",
    outputPath: "销售报表.xlsx",
    model: reportData
);
```

不要求调用方理解 Excel COM，也不要求调用方手动管理 Excel.Application、Workbook、Worksheet、Range 等 COM 对象。

### 1.3 目标用户

| 角色      | 主要需求                      |
| ------- | ------------------------- |
| 模板设计人员  | 在 Excel 中可视化设计模板、定义循环和占位符 |
| C# 开发人员 | 通过对象传入数据，一行代码生成 Excel     |
| 系统集成人员  | 管理生成任务、异常、超时和 Excel 进程    |
| 组件维护人员  | 扩展图片、图表、艺术字、数据类型和模板指令     |

### 1.4 设计原则

- 零侵入模板：直接使用标准 Excel 文件，不引入专用编辑器。
- 对象优先：业务数据以强类型 C# 对象表示，不强制使用 DataTable 或 Dictionary。
- 声明式语法：模板中声明填什么、在哪里循环，而非写 C# 代码。
- 原生复制：复杂样式和 Excel 对象优先交给 Excel 自身复制处理。
- 安全执行：不运行模板中的任意表达式、脚本或宏。
- 生命周期封闭：每次渲染具有明确的资源所有权和退出策略。

## 二、功能范围

| 功能模块     | 能力                    | 优先级 |
| -------- | --------------------- | --- |
| 基础填充     | 字符串、数字、日期、布尔、枚举、空值    | P0  |
| 对象填充     | 属性路径、嵌套对象、Dictionary  | P0  |
| 表单填充     | 固定位置单元格占位符            | P0  |
| 列表填充     | 纵向循环、动态行插入            | P0  |
| 多 Sheet  | 指定 Sheet、跨 Sheet 数据引用 | P0  |
| 图片填充     | 图片占位形状、缩放、裁剪、定位       | P0  |
| 艺术字填充    | 保留 WordArt 原有样式并替换文字  | P0  |
| 样式保留     | 边框、字体、合并、条件格式、行高列宽    | P0  |
| 进程管理     | STA、COM 释放、隔离进程、超时    | P0  |
| 横向循环     | 动态扩展列                 | P1  |
| 动态 Sheet | 按集合复制模板 Sheet         | P1  |
| 条件块      | 根据对象属性控制内容显示          | P1  |
| 图表填充     | 更新图表数据源和标题            | P1  |
| 嵌套循环     | 父子集合、明细分组             | P1  |
| 模板检查器    | 语法、区域冲突、数据路径校验        | P1  |
| 富文本及特殊对象 | SmartArt、OLE、复杂嵌入对象   | P2  |

兼容性边界：Excel COM 能访问大量原生 Excel 功能，但不等于可以保证每一种 Excel 对象、所有版本中的行为都完全一致。组件应尽量保留不修改的内容，对主动修改的对象类型建立明确的兼容清单。

## 三、模板语法设计

这是整个组件最关键的设计。

建议使用 `{{ }}` 作为数据占位符，`{{#...}}` 和 `{{/...}}` 作为控制指令。语法借鉴 Mustache，但根据 Excel 的二维结构进行扩展，不直接套用 HTML 模板引擎。

### 3.1 基础变量占位符

| 模板写法                                  | 含义                 |
| ------------------------------------- | ------------------ |
| `{{CustomerName}}`                    | 当前对象的 CustomerName |
| `{{Customer.Address}}`                | 嵌套属性               |
| `{{Order.Total}}`                     | 订单金额               |
| `{{@root.CompanyName}}`               | 根对象属性              |
| `{{@parent.Name}}`                    | 父级循环对象属性           |
| `{{@index}}`                          | 当前循环序号，从 1 开始      |
| `{{@count}}`                          | 当前循环集合总数量          |
| `{{Amount \\| number:"#,##0.00"}}`    | 数字格式               |
| `{{CreatedAt \\| date:"yyyy-MM-dd"}}` | 日期格式               |
| `{{Name \\| default:"未填写"}}`          | 空值默认值              |

示例：Excel 中的单元格写入 `客户名称：{{Customer.Name}}`，最终替换为 `客户名称：华星科技`。

格式化仅允许预先注册的格式器，不允许在模板中执行任意 C# 代码。

### 3.2 表单式填充

表单填充不改变 Excel 布局，只替换对应单元格中的数据。

Excel 模板示意

固定区域

| 行 | A 列     | B 列                                | C 列 |
| - | ------- | ---------------------------------- | --- |
| 1 | 客户信息登记表 |                                    |     |
| 2 | 客户名称    | {{Customer.Name}}                  |     |
| 3 | 联系电话    | {{Customer.Phone}}                 |     |
| 4 | 登记日期    | {{CreatedAt \| date:"yyyy-MM-dd"}} |     |

模板设计人员只需输入占位符，原有边框、字体、合并区域和打印设置不变。

### 3.3 纵向循环语法

推荐使用块指令：

```
{{#each Orders}}
    {{@index}}  {{ProductName}}  {{Quantity}}  {{Price}}
{{/each}}
```

但 Excel 不同于纯文本，循环必须明确其作用范围。

推荐规范：循环起止标记分别独占一行的指定标记单元格，循环体为两者之间的完整行。

例如：

模板设计

| 行号 | A 列              | B 列             | C 列          |
| -- | ---------------- | --------------- | ------------ |
| 5  | {{#each Orders}} |                 |              |
| 6  | {{@index}}       | {{ProductName}} | {{Quantity}} |
| 7  | {{/each}}        |                 |              |
| 8  | 合计               | {{TotalAmount}} |              |

标记行仅用于定义循环区域，渲染后删除。

如果 Orders 包含 3 个对象，渲染结果为：

渲染结果

| 行号 | A 列 | B 列  | C 列 |
| -- | --- | ---- | --- |
| 5  | 1   | 产品 A | 2   |
| 6  | 2   | 产品 B | 5   |
| 7  | 3   | 产品 C | 1   |
| 8  | 合计  |      | 8   |

实现规则：

- 循环体允许多行，包括合并单元格、图片和艺术字。
- 每个循环项复制一份完整循环体，而不是只复制单元格值。
- 通过 Excel COM 的 Range.Copy、Insert 等操作保留样式。
- 循环块下方内容随新增行整体移动。
- 空集合时移除循环体与标记行。
- 起止标记行不得包含需要保留的业务内容。
- 标记行必须独占逻辑行；若与其他区域冲突，应在预检查阶段报错。

### 3.4 横向循环

用于动态月份、部门、分类等列结构。

```
{{#each Months direction="right"}}
    {{Name}}
{{/each}}
```

其行为是复制完整的模板列区域，并向右扩展。

需要额外处理公式引用、合并区域、图表引用及打印区域。v1.0 可先实现纵向循环，横向循环作为 v1.1 功能。

### 3.5 嵌套循环

例如订单集合内包含订单明细：

```
{{#each Orders}}
    订单：{{OrderNo}}
    客户：{{CustomerName}}

    {{#each Items}}
        {{@index}}  {{ProductName}}  {{Qty}}
    {{/each}}

    订单合计：{{Total}}
{{/each}}
```

作用域规则：

- `{{Name}}` 优先解析当前循环项。
- `{{@parent.Name}}` 访问直接父级。
- `{{@root.Name}}` 访问根对象。
- `{{@index}}` 访问当前层序号。

嵌套循环的执行顺序为从内层生成结构，再向外层展开，或通过递归区域渲染实现同等效果。必须避免直接用原始 Excel 行号在多次插入后定位区域。

### 3.6 条件语法

```
{{#if IsVip}}
    VIP 专属内容
{{/if}}
```

支持布尔属性和注册的条件判断器。

首版不建议引入复杂表达式，例如 `Amount > 1000 && IsVip`，以避免模板语言膨胀、安全问题和解析复杂度。

### 3.7 Sheet 循环

动态生成多个工作表，推荐采用 工作表级声明，而不是在单元格中混入跨 Sheet 循环。

通过 Excel 自定义属性、工作表局部定义名称，或组件约定的隐藏配置 Sheet 记录：

```
SheetTemplate: DetailTemplate
RepeatSource: Departments
SheetName: {{Name}}
```

一个 Departments 集合可以生成：

- 华东区
- 华南区
- 华北区

每个 Sheet 内部的 `{{Name}}` 指向当前 Department，`{{@root.CompanyName}}` 仍指向根对象。

必须处理 Sheet 名非法字符、31 字符限制、重名、空集合以及复制后图表与公式引用。

## 四、统一数据模型

### 4.1 外部调用方：直接传入业务对象

不建议让每个调用方都手动创建一棵复杂的模板节点树。

推荐直接支持：

```
public class SalesReport
{
    public string CompanyName { get; set; } = "";
    public DateTime ReportDate { get; set; }
    public CustomerInfo Customer { get; set; } = new();
    public List<OrderInfo> Orders { get; set; } = new();
    public ImageValue? Logo { get; set; }
}

public class CustomerInfo
{
    public string Name { get; set; } = "";
    public string Phone { get; set; } = "";
}

public class OrderInfo
{
    public string ProductName { get; set; } = "";
    public int Quantity { get; set; }
    public decimal Price { get; set; }
}
```

调用：

```
var report = new SalesReport
{
    CompanyName = "华星科技",
    ReportDate = DateTime.Today,
    Customer = new CustomerInfo
    {
        Name = "张三",
        Phone = "13800000000"
    },
    Orders = new()
    {
        new() { ProductName = "产品A", Quantity = 2, Price = 100 },
        new() { ProductName = "产品B", Quantity = 3, Price = 200 }
    },
    Logo = ImageValue.FromFile("logo.png")
};

renderer.Render("template.xlsx", "result.xlsx", report);
```

### 4.2 内部统一节点模型

引擎内部统一转换为如下抽象结构：

```
public enum TemplateValueKind
{
    Null,
    Scalar,
    Object,
    Collection,
    Image,
    WordArt,
    Chart
}

public interface ITemplateValue
{
    TemplateValueKind Kind { get; }
    object? RawValue { get; }
}

public interface ITemplateDataAdapter
{
    ITemplateValue Adapt(object? value);
}
```

ReportData 数据树

Root : Object

CompanyName : Scalar

ReportDate : Scalar

Customer : Object

Name : Scalar

Phone : Scalar

Orders : Collection

[0] : Object → ProductName, Quantity, Price

[1] : Object → ProductName, Quantity, Price

Logo : Image

建议同时支持 POCO、匿名对象、Dictionary、DataTable、IEnumerable，以及通过适配器扩展自定义数据类型。

### 4.3 为什么区分图片、艺术字、图表类型？

因为这些不是简单的字符串替换。

| 数据类型       | 目标 Excel 对象       | 渲染行为               |
| ---------- | ----------------- | ------------------ |
| Scalar     | Range             | 写入单元格值             |
| Image      | Shape             | 替换图片内容并保持布局        |
| WordArt    | Shape             | 修改 TextEffect.Text |
| Chart      | ChartObject       | 更新数据源或系列           |
| Collection | Range / Worksheet | 复制行列或 Sheet        |
| Object     | 作用域               | 提供属性解析上下文          |

核心原则：复杂对象的数据模型和其在 Excel 中的呈现方式分离。

## 五、图片与艺术字模板设计

### 5.1 图片模板

建议使用 Excel 中的 形状名称 作为对象定位入口，而不是把图片硬塞进单元格。

模板设计人员可以在 Excel 的“选择窗格”中，将图片形状命名为：

```
tpl:image:Logo
tpl:image:Customer.Photo
```

或者在图片的替代文字中写入：

```
{{image:Logo}}
```

推荐以形状名称作为稳定标识，替代文字作为可选兼容方式。

图片数据结构：

```
public sealed class ImageValue
{
    public byte[]? Bytes { get; init; }
    public string? FilePath { get; init; }
    public ImageFit Fit { get; init; } = ImageFit.Contain;
    public bool KeepAspectRatio { get; init; } = true;
}

public enum ImageFit
{
    Contain,
    Cover,
    Stretch
}
```

渲染行为：

1. 找到图片占位 Shape。
2. 记录其位置、尺寸、旋转、层级和定位方式。
3. 从字节数组或文件加载目标图片。
4. 插入图片并按 Fit 规则计算缩放或裁剪。
5. 恢复需要保留的形状属性。
6. 删除旧占位形状并释放临时资源。

对于 `Cover`，应采用 Excel 支持的裁剪能力或受控图片预处理，不能简单拉伸变形。

### 5.2 艺术字模板

Excel 的 WordArt 本质上属于 Shape，可以通过 COM 操作其 TextEffect 属性。

模板形状名称：

```
tpl:wordart:Title
```

模板内可以预先设计字体、渐变、旋转、阴影、三维效果等。

数据对象：

```
public sealed class WordArtValue
{
    public string Text { get; init; } = "";
}
```

渲染核心：

```
shape.TextEffect.Text = wordArtValue.Text;
```

与图片不同，艺术字推荐 直接修改原有 Shape，而不是删除后重建，这样更有利于保留模板设计的视觉属性。

但仍需要验证特定 Excel 版本下艺术字文本修改后是否会自动调整尺寸、换行和效果。

### 5.3 循环区域中的图片与艺术字

例如员工档案模板：

员工信息卡模板

循环体内包含 Shape

tpl:image:Photo

{{Name}}

工号：{{EmployeeNo}}

部门：{{Department}}

艺术字标题：tpl:wordart:Title

一个员工对象对应一张卡片，循环复制完整行区域后，必须为每份复制的 Shape 建立独立的对象映射，防止所有图片最终被替换成最后一个员工的照片。

这也是本组件区别于普通模板填充库的重要能力。

## 六、渲染引擎总体架构

建议采用 解析、规划、执行三阶段架构，不要一边扫描 Excel，一边直接插入行、删除行和替换数据。

### 6.1 模块划分

| 模块                        | 职责                    |
| ------------------------- | --------------------- |
| ExcelTemplate.Core        | 数据抽象、AST、作用域、路径解析、格式器 |
| ExcelTemplate.Parser      | Excel 模板扫描、语法解析、校验    |
| ExcelTemplate.Planner     | 循环区域展开、依赖分析、执行计划      |
| ExcelTemplate.Com         | Excel COM 操作适配层       |
| ExcelTemplate.Worker      | 独立 STA 进程、执行和资源管理     |
| ExcelTemplate.Client      | 对外简洁 API、Worker 通信    |
| ExcelTemplate.Diagnostics | 诊断日志、模板检查、错误定位        |

### 6.2 内部模板 AST

```
public abstract record TemplateNode;

public record TextNode(string Text)
    : TemplateNode;

public record ValueNode(
    string Path,
    string? Formatter)
    : TemplateNode;

public record EachNode(
    string Path,
    RepeatDirection Direction,
    IReadOnlyList<TemplateNode> Children)
    : TemplateNode;

public record IfNode(
    string Path,
    IReadOnlyList<TemplateNode> Children)
    : TemplateNode;

public record ShapeNode(
    string ShapeName,
    string Path,
    ShapeBindingKind Kind)
    : TemplateNode;
```

AST 节点还需要关联源位置：

```
public record TemplateLocation(
    string SheetName,
    string? CellAddress,
    string? ShapeName);
```

以便错误能够定位到 `销售明细!A12` 或 `员工卡!tpl:image:Photo`，而不是只返回一个模糊的 COM 异常。

### 6.3 渲染执行阶段

1. 加载与预检：打开模板副本，扫描 Sheet、占位符、Shape、循环块，生成模板 AST，验证语法和区域合法性。
2. 构建执行计划：绑定数据上下文，计算每个循环块的扩展数量，生成逻辑区域和 Shape 映射。
3. 结构展开：先复制动态 Sheet，再按规划执行行列扩展，处理嵌套循环、条件区域和合并单元格。
4. 内容绑定：填充单元格、图片、艺术字和图表，使用循环实例的独立作用域。
5. Excel 收尾：按配置执行公式重算、打印区域修正、分页处理和外部链接检查。
6. 保存与退出：保存临时输出文件，关闭 Workbook、退出 Excel、释放 COM 资源，验证文件后原子替换正式输出。

特别注意：嵌套循环不能仅依赖“从下往上插入行”这一技巧。执行计划需要维护模板区域到生成区域的映射，支持每个循环实例独立定位。底层可以采用自底向上插入策略减少地址偏移，但它只是实现手段。

## 七、Excel COM 核心设计

### 7.1 COM 操作封装

禁止业务代码直接访问原始 Excel COM 对象。

```
public interface IExcelWorkbookSession
{
    void Open(string templatePath);
    void CopyRows(string sheet, int startRow,
                  int rowCount, int copies);
    void SetCellValue(string sheet, string address,
                      object? value);
    void SetShapeImage(string sheet, string shapeName,
                       ImageValue image);
    void SetWordArtText(string sheet, string shapeName,
                        string text);
    void SaveAs(string outputPath);
}
```

COM 适配层内部负责对象获取、调用、释放及错误转换。

### 7.2 COM 线程模型

Excel COM Automation 使用 STA 模型。推荐每个 Worker 进程维护一个专用 STA 执行线程。

- Excel.Application 在 STA 线程创建。
- 所有 COM 对象只能在所属 STA 执行上下文中操作。
- 不允许通过 Task.Run 将 Excel COM 操作分发到线程池。
- 不允许多个线程同时操作同一个 Workbook。
- Worker 需要具备合适的 Windows 消息泵，并针对 Excel 忙碌状态处理可重试的 COM 调用。
- 任务队列按顺序执行；并发由多个 Worker 进程实现。

### 7.3 COM 资源释放规范

这是项目的硬性质量要求。

```
Excel.Application? app = null;
Excel.Workbooks? books = null;
Excel.Workbook? book = null;

try
{
    app = new Excel.Application();
    app.Visible = false;
    app.DisplayAlerts = false;

    books = app.Workbooks;
    book = books.Open(templatePath);

    // 执行模板渲染
    // ...
}
finally
{
    if (book != null)
    {
        try { book.Close(false); }
        catch { /* 记录异常 */ }
    }

    if (app != null)
    {
        try { app.Quit(); }
        catch { /* 记录异常 */ }
    }

    ReleaseCom(book);
    ReleaseCom(books);
    ReleaseCom(app);
}
```

示例仅展示生命周期原则。实际实现必须将 Range、Worksheet、Shapes、Shape、Chart、枚举器及其他中间 COM 引用纳入管理。

推荐使用严格的作用域封装，并确保每个 COM 引用有明确所有者。避免在多个包装器之间随意使用 `FinalReleaseComObject`，否则可能提前释放仍被使用的共享 RCW。

`GC.Collect()` 不能代替确定性的 COM 释放，也不能作为 Excel 进程退出的唯一保障。

## 八、Excel 进程隔离与管理

这是我建议重点投入设计的部分。

不要把 Excel.Application 直接放在业务主进程中长期运行。

推荐使用独立的 `ExcelTemplate.Worker.exe` 进程执行模板渲染。

### 8.1 生命周期策略

建议默认采用 一个渲染任务对应一个 Worker 进程、一个 Excel 实例。

虽然进程启动存在开销，但有三个显著优势：

1. 任务之间不存在 COM 状态污染。
2. 内存、Excel 进程和临时资源容易界定。
3. 出现 Excel 卡死时，可以直接终止当前任务所属进程树。

后续可以增加 Worker 复用模式，但不建议作为首版默认方案。

### 8.2 超时与异常恢复

推荐执行策略：

| 情况            | 处理方式                          |
| ------------- | ----------------------------- |
| 正常完成          | 保存、关闭 Excel、释放 COM、退出 Worker  |
| 模板解析失败        | 返回结构化错误，不进入渲染阶段               |
| COM 操作失败      | 记录阶段和对象位置，尝试正常关闭              |
| Excel 无响应     | 超时后终止专属 Worker 与其拥有的 Excel 进程 |
| 调用方取消         | 先请求协作取消，超时后强制终止               |
| 输出文件保存失败      | 保留原输出文件，清理临时文件                |
| Excel 弹出隐藏对话框 | 由超时机制处理，并尽量预防交互式提示            |

必须记录由本 Worker 启动的 Excel 进程 PID 或通过受控进程关联机制建立所有权，绝不能通过进程名批量结束系统中所有 Excel.exe，否则可能关闭用户正在编辑的工作簿。

在 Windows 上可考虑 Job Object 辅助管理 Worker 进程树，同时对 Excel 进程身份进行核验。不能假定所有 Excel COM 激活场景都会创建一个全新且独立的 Excel.exe；需要设计实例归属验证，防止误伤其他 Excel 会话。

### 8.3 运行环境限制

Excel COM 自动化依赖 Windows 和已安装、已正确配置的桌面版 Excel。

Microsoft 不推荐将 Office Automation 用于无人值守的服务器端场景，因此本产品应将 交互式 Windows 桌面或受控专用自动化工作站 作为优先部署环境。Windows Service、IIS 后台无人值守场景不应承诺生产级稳定支持。

对于高并发 Web 报表系统，应考虑将渲染任务交给专门的 Windows 工作站代理，并限制并发量。

## 九、对外 API 设计

对外 API 应当足够简单，复杂能力放到可选配置中。

### 9.1 核心接口

```
public interface IExcelTemplateRenderer
{
    RenderResult Render<T>(
        string templatePath,
        string outputPath,
        T model,
        RenderOptions? options = null);

    Task<RenderResult> RenderAsync<T>(
        string templatePath,
        string outputPath,
        T model,
        RenderOptions? options = null,
        CancellationToken cancellationToken = default);

    TemplateValidationResult Validate(
        string templatePath);
}
```

`RenderAsync` 表示异步等待独立 Worker 执行，不表示 Excel COM 本身可以跨线程并行调用。

### 9.2 渲染配置

```
public sealed class RenderOptions
{
    public TimeSpan Timeout { get; init; }
        = TimeSpan.FromMinutes(3);

    public bool RecalculateFormulas { get; init; } = true;

    public bool PreserveMacros { get; init; } = true;

    public bool UpdateExternalLinks { get; init; } = false;

    public MissingValueBehavior MissingValue { get; init; }
        = MissingValueBehavior.Throw;

    public EmptyCollectionBehavior EmptyCollection { get; init; }
        = EmptyCollectionBehavior.RemoveBlock;

    public bool ValidateBeforeRender { get; init; } = true;

    public bool KeepDiagnosticFiles { get; init; } = false;
}
```

### 9.3 结果对象

```
public sealed record RenderResult
{
    public bool Success { get; init; }
    public string? OutputPath { get; init; }
    public TimeSpan Duration { get; init; }

    public IReadOnlyList<TemplateDiagnostic> Diagnostics
        { get; init; } = [];
}

public sealed record TemplateDiagnostic(
    string Code,
    string Message,
    string? SheetName,
    string? CellAddress,
    string? ShapeName);
```

建议失败时区分两种模式：默认抛出类型化异常，或通过 `TryRender` 风格 API 返回失败结果，避免调用方误以为 `Success = false` 的文件已成功生成。

### 9.4 可扩展接口

```
public interface ITemplateFormatter
{
    string Name { get; }

    object? Format(
        object? value,
        string? argument);
}

public interface ITemplateObjectBinder
{
    bool CanBind(TemplateValueKind kind);

    void Bind(
        IExcelBindingContext context,
        ITemplateValue value);
}
```

后续支持二维码、条形码、签名、图表、富文本等，都可以通过注册绑定器扩展，而不需要修改模板解析核心。

## 十、模板约定与冲突规则

为保证组件真正通用，需要制定一套明确的模板约束。

| 场景          | 建议规则                                |
| ----------- | ----------------------------------- |
| 单元格占位符      | `{{Property}}`                      |
| 纵向循环        | `{{#each Items}}`                   |
| 横向循环        | `{{#each Items direction="right"}}` |
| 条件块         | `{{#if Enabled}}`                   |
| 图片          | Shape 名称 `tpl:image:Photo`          |
| 艺术字         | Shape 名称 `tpl:wordart:Title`        |
| 图表          | Shape 名称 `tpl:chart:Sales`          |
| 动态 Sheet    | 工作表局部定义名称或隐藏配置表                     |
| 特殊字符        | `\{{` 表示字面量 `{{`                    |
| 缺失属性        | 默认报错，允许配置为空值                        |
| 重复 Shape 名称 | 在同一逻辑作用域内报错                         |
| 区域交叉        | 不允许两个循环区域部分重叠                       |
| 合并单元格       | 不允许跨越循环边界                           |
| 公式单元格       | 默认保留公式，不做字符串占位符替换                   |

对于包含公式的循环区域，需要定义引用策略：

- 相对引用随 Excel 复制操作自动调整。
- 绝对引用尽量保留原有语义。
- 跨 Sheet 引用和命名区域需进行验证。
- 动态扩展可能影响结构化表、数据透视表和图表引用，应按类型处理。
- 对于无法保证安全调整的公式，给出诊断信息，而不是静默修改。

## 十一、模板校验器

模板校验器应当成为产品正式功能，而不是调试工具。

建议提供：

```
var validation = renderer.Validate("template.xlsx");
```

检查范围包括语法正确性、循环块匹配、合并单元格跨界、Shape 命名冲突、Sheet 名冲突、公式风险、模板保护状态、外部链接和不支持的对象。

还可以增加带数据模型的预校验：

```
var validation = renderer.Validate(
    "template.xlsx",
    typeof(SalesReport));
```

例如：

TPL1003 · 属性不存在

Sheet：销售明细

位置：C8

表达式：`{{Customer.MobileNumber}}`

原因：CustomerInfo 中不存在 MobileNumber 属性。

TPL2011 · 合并单元格跨越循环边界

Sheet：销售明细

区域：B10:D14

建议：将合并区域完整放入循环体内。

## 十二、非功能性要求与验收标准

| 维度   | 验收要求                        |
| ---- | --------------------------- |
| 正确性  | 单元格、图片、艺术字和循环作用域绑定正确        |
| 模板保真 | 未修改区域的样式、公式、形状和打印设置尽量保持一致   |
| 进程隔离 | 单任务异常不影响其他任务及用户 Excel 会话    |
| 资源释放 | 正常及异常结束后不遗留组件拥有的 Excel 进程   |
| 超时控制 | 任务超过设定时限后可被终止和清理            |
| 文件安全 | 不覆盖源模板，失败时不产生伪成功输出          |
| 可诊断性 | 错误包含 Sheet、单元格、Shape、阶段和错误码 |
| 安全性  | 默认禁用宏执行、外部链接自动更新和不受信任的主动内容  |
| 可扩展性 | 新增格式器或对象绑定器不需要修改核心解析器       |

性能指标不建议直接承诺固定秒数。应先建立标准基准模板，例如 100、1,000、10,000 行明细，以及带 100 张图片的员工档案模板，分别测量 Excel 启动、模板解析、区域复制、数据写入和保存时间。

COM 调用次数通常是重要性能因素。对于连续单元格，应优先采用二维数组批量写入 `Range.Value2`，避免逐单元格跨进程调用。

## 十三、测试方案

重点建立以下测试矩阵：

- 基础测试：空值、数字、日期、中文、特殊字符、属性不存在。
- 循环测试：0、1、100、10,000 项；多行循环；嵌套循环；横向循环；跨 Sheet 循环。
- 复杂模板测试：合并单元格、公式、条件格式、图表、分页、图片、艺术字、隐藏行列。
- 异常测试：Excel 卡死、文件被占用、模板损坏、磁盘空间不足、调用方取消。
- 资源测试：连续运行数百次，检查 Excel 进程、句柄、内存及临时文件是否持续增长。
- 兼容测试：按实际支持的 Windows、Office 版本、32/64 位环境建立测试矩阵。

其中最重要的自动化测试不是单纯比较 Excel 文件字节，而是比较生成后的单元格值、公式、Sheet 结构、Shape 数量与位置、样式及打印属性。

## 十四、开发里程碑

M1

最小可用引擎

2–3 周

POCO 数据、变量填充、纵向循环、模板校验、基础 COM Worker

M2

复杂对象模板

2–3 周

图片、艺术字、多行循环、Shape 映射、合并单元格处理

M3

高级结构

3–4 周

嵌套循环、横向循环、动态 Sheet、条件块、公式处理

M4

稳定性与发布

2–3 周

异常恢复、进程回收、性能优化、兼容性测试、示例模板

以上是单一小团队的初步估算，实际周期取决于 Excel 复杂对象兼容范围和自动化测试环境。

## 十五、关键技术决策

| 决策项      | 推荐方案            | 原因                |
| -------- | --------------- | ----------------- |
| 模板语言     | `{{ }}` 声明式语法   | 易读、易维护            |
| 数据输入     | POCO + Adapter  | 调用方使用成本低          |
| 数据内部表示   | 统一数据节点 + 作用域    | 支持嵌套与复杂对象         |
| 模板解析     | AST + 区域定位      | 避免直接替换带来的结构问题     |
| 循环执行     | 先规划后展开          | 控制行列偏移和嵌套区域       |
| 图片定位     | Shape 名称        | 便于 Excel 模板设计     |
| 艺术字填充    | 修改原 Shape       | 最大限度保留原始效果        |
| COM 生命周期 | 独立 Worker + STA | 资源边界清晰            |
| 默认任务隔离   | 一任务一进程          | 优先稳定性             |
| 并发方式     | 多 Worker 受控并发   | 避免共享 Excel COM 状态 |
| 失败处理     | 结构化诊断 + 临时输出    | 可排查、可恢复           |

## 十六、最终产品形态

建议最终交付以下组件：

```
ExcelTemplateEngine/
├── src/
│   ├── ExcelTemplate.Core/
│   ├── ExcelTemplate.Parser/
│   ├── ExcelTemplate.Planner/
│   ├── ExcelTemplate.Com/
│   ├── ExcelTemplate.Client/
│   └── ExcelTemplate.Worker/
│
├── tests/
│   ├── UnitTests/
│   ├── IntegrationTests/
│   └── ExcelCompatibilityTests/
│
├── samples/
│   ├── FormReport/
│   ├── ListReport/
│   ├── NestedReport/
│   ├── ImageReport/
│   ├── WordArtReport/
│   └── MultiSheetReport/
│
└── docs/
    ├── 产品设计文档
    ├── 模板语法规范
    ├── 开发接入指南
    └── COM进程管理规范
```

### 最需要提前验证的三个技术风险

第一，循环复制后的 Shape 映射。 Excel 复制行并不意味着所有浮动 Shape 都会按照业务预期被复制、定位和命名。需要针对 Shape.Placement、锚定单元格、分组形状和复制策略建立独立的对象管理机制。

第二，公式和复杂 Excel 对象的结构调整。 复制行列时 Excel 会自动处理一部分引用，但图表、数据透视表、名称管理器、条件格式等不一定都能获得预期结果。必须定义支持边界。

第三，Excel COM 进程所有权。 单纯调用 `Quit()` 和 `ReleaseComObject()` 不足以保证所有故障场景都能干净退出。必须结合 Worker 隔离、实例归属验证、超时和进程回收设计。

## 产品结论

这款组件应当建立两个核心抽象：

数据侧： `TemplateData → Object / Collection / Scalar / Image / WordArt`

模板侧： `TemplateNode → Value / Each / If / Shape / Sheet`

两者通过 RenderContext 绑定，最终由 Excel COM Executor 完成操作。

这样设计既能让普通调用方保持：

```
renderer.Render(template, output, data);
```

又能让复杂模板拥有循环、嵌套、动态 Sheet、图片和艺术字等能力。

建议第一阶段优先实现“表单填充 + 纵向循环 + 图片/艺术字 + 独立 Worker 进程管理”这条完整链路。 这是验证产品核心价值、模板保真度和 COM 稳定性的最小闭环。