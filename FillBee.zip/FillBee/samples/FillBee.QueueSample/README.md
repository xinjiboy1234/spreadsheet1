# FillBee 队列与并发示例

此项目自动创建自己的 Excel 模板，不依赖其他示例输出。需要 Windows、.NET 10 SDK、桌面 Excel。

## 运行

```powershell
# 一次运行四种场景，默认每批6个任务、并发场景2个执行槽
dotnet run --project samples/FillBee.QueueSample -- all

# 多个调用方一起提交，队列一次只执行一个
dotnet run --project samples/FillBee.QueueSample -- serial

# 多个调用方一起提交，队列同时执行两个
dotnet run --project samples/FillBee.QueueSample -- parallel

# 错误模板任务失败，其他任务仍成功；调用方捕获预期异常
dotnet run --project samples/FillBee.QueueSample -- recovery

# 等待时取消、执行时取消、任务超时，随后继续生成正常报告
dotnet run --project samples/FillBee.QueueSample -- cancel

# 自定输出根目录、任务数、并发槽数
dotnet run --project samples/FillBee.QueueSample -- parallel "D:\Reports\QueueDemo" 12 4
```

参数顺序：`模式 输出根目录 任务数 并发槽数`。任务数范围2到200；并发槽范围1到8且不能超过任务数。未提供输出根目录时使用程序目录下 `artifacts`，每次运行创建唯一子目录。按 Ctrl+C 取消。

每条控制台日志包含相对时间、活跃任务数、开始/完成/取消/异常及任务名。`提交`不代表已经开始执行；队列满时入队异步等待，释放槽位后继续。多个并发任务的完成顺序可能不同。

## 调用方式

```csharp
await using var queue = new RenderQueue(
    new ExcelRenderExecutor(),
    capacity: 2,        // 等待中的任务容量，不含正在执行的任务
    maxConcurrency: 2  // 同时执行的任务数，默认1
);

var tasks = Enumerable.Range(1, 6).Select(i =>
    queue.EnqueueAsync(new RenderJob(
        templatePath,
        Path.Combine(outputFolder, $"report-{i}.xlsx"),
        CreateModel(i),
        new RenderOptions(Timeout: TimeSpan.FromMinutes(2))),
        cancellationToken));

RenderResult[] results = await Task.WhenAll(tasks);
```

`CreateModel(i)`代表业务方为各任务准备的数据，可参考项目 `Program.cs` 中的 `Job` 方法。公共 `ExcelRenderExecutor` 将队列任务转交给渲染器；默认每个任务使用独立 Worker 和 Excel COM 实例。

串行队列按出队顺序开始执行。并发队列限制正在执行的数量，任务完成后即开始后续任务；多个生产者真正同时提交时，先到队列的任务先出队，不应依赖调用方的数字编号排序。

每个任务使用不同的输出路径，模板文件可以只读共享。不要让多个任务写入同一个输出文件，不要在执行期间修改共享模型或模板。自定义 IRenderExecutor 在 maxConcurrency>1 时也必须能承受并发调用。

DisposeAsync 停止接收新工作，等待所有已接收任务结束，然后释放执行器。若要提前停止任务，使用入队时传入的 CancellationToken；执行器须配合取消。自定义执行器忽略取消时，队列不能强制中止它。强制终止 Excel 由默认 Worker 负责。

超时从任务获得执行槽时计算，等待入队/等待执行的时间不计入任务超时；如需限制总等待时间，请使用 CancellationTokenSource.CancelAfter。调用方取消可能先返回；该执行槽会等待 Worker 清理结束后才处理下一个任务。

## 场景检查什么

| 场景 | 检查 |
| --- | --- |
| serial | 6个任务均成功；启动顺序与入队顺序一致；峰值活跃数为1 |
| parallel | 6个任务均成功；默认峰值活跃数为2；每份报告包含对应任务数据 |
| recovery | 错误模板不发布输出；同时执行和随后提交的正常任务成功 |
| cancel | 取消的排队任务不启动执行器；执行取消/超时不发布结果；后续报告成功 |

成功报告还检查实际引用的单元格没有残留占位符、动态 Sheet 数为5、图片和图表部件存在。各个任务使用不同公司名称检测串数据。

所有选中场景结束后，比较 Excel 进程的 PID 和启动时间与运行前快照，检查是否有新增进程残留，并检查输出目录的暂存文件。示例只观察进程，不结束用户其他 Excel 实例；验证期间请勿自行启动额外 Excel，否则可能被观察检查视为新进程。

`summary.json` 保存各场景计数、峰值、批次耗时，以及进程/暂存文件检查结果。成功生成的报告、模板、图片保留供人工查看。

## 取消启动时序

取消发生在 Excel COM 激活期间时，可能尚未取得 HWND/PID。Worker 现在先接收取消信号，父进程最多等待15秒让激活完成并写入完整身份记录，再结束 Worker 并核对清理 Excel。若 COM 激活长期卡死、在此期限内始终无法提供身份，无法按身份确认其 Excel 实例；此故障边界不属于普通并发成功的保证。

## 无需 Excel 的队列检查

```powershell
dotnet run --project tests/FillBee.QueueChecks
```

覆盖并发上限、单槽顺序、容量背压、等待任务取消、错误隔离、超时与非法参数、释放排空和重复释放。

这些检查和真实 Excel 场景说明当前机器上的验证结果，不能保证所有 Office 版本、模板与并发规模均不报错。建议从1到2个执行槽开始，按实际模板增加负载；并发较高时 Excel 启动和 COM 竞争可能让单任务耗时增加。
