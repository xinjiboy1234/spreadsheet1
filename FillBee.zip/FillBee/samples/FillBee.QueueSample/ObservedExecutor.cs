using System.Diagnostics;
using FillBee;

namespace FillBee.QueueSample;

internal sealed class ObservedExecutor : IRenderExecutor
{
    private readonly ExcelRenderExecutor _inner = new();
    private readonly Stopwatch _clock = Stopwatch.StartNew();
    private readonly object _gate = new();
    private int _active;
    public int Peak { get; private set; }
    public List<string> StartOrder { get; } = [];
    public TaskCompletionSource FirstStarted { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);

    public async Task<RenderResult> ExecuteAsync(RenderJob job, CancellationToken cancellationToken)
    {
        string id = Path.GetFileNameWithoutExtension(job.OutputPath);
        lock (_gate)
        {
            _active++;
            Peak = Math.Max(Peak, _active);
            StartOrder.Add(id);
            Log("开始", id);
        }
        FirstStarted.TrySetResult();
        try
        {
            var result = await _inner.ExecuteAsync(job, cancellationToken);
            lock (_gate) Log("完成", id);
            return result;
        }
        catch (Exception ex)
        {
            lock (_gate) Log(ex is OperationCanceledException ? "取消" : "异常", $"{id}: {ex.GetType().Name}");
            throw;
        }
        finally { lock (_gate) _active--; }
    }

    private void Log(string state, string id)
        => Console.WriteLine($"{_clock.Elapsed.TotalSeconds,6:F1}s | 活跃 {_active} | {state} | {id}");
    public ValueTask DisposeAsync() => _inner.DisposeAsync();
}
