using System.IO.Compression;
using System.Xml.Linq;

namespace FillBee.QueueSample;

internal static class ReportCheck
{
    public static void Verify(string path, string company)
    {
        if (!File.Exists(path)) throw new InvalidDataException($"报告未生成：{path}");
        using var zip = ZipFile.OpenRead(path);
        XNamespace ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
        XDocument Read(ZipArchiveEntry entry) { using var stream = entry.Open(); return XDocument.Load(stream); }
        var sharedEntry = zip.GetEntry("xl/sharedStrings.xml");
        var shared = sharedEntry is null ? [] : Read(sharedEntry).Descendants(ns + "si")
            .Select(si => string.Concat(si.Descendants(ns + "t").Select(t => t.Value))).ToArray();
        var texts = new List<string>();
        foreach (var entry in zip.Entries.Where(e => e.FullName.StartsWith("xl/worksheets/sheet") && e.FullName.EndsWith(".xml")))
        foreach (var cell in Read(entry).Descendants(ns + "c"))
        {
            if ((string?)cell.Attribute("t") == "s")
                texts.Add(shared[int.Parse(cell.Element(ns + "v")!.Value)]);
            else if ((string?)cell.Attribute("t") == "inlineStr")
                texts.Add(string.Concat(cell.Descendants(ns + "t").Select(t => t.Value)));
        }
        if (!texts.Any(t => t.Contains(company, StringComparison.Ordinal)))
            throw new InvalidDataException($"{path}: 任务数据未写入，可能发生串数据。");
        if (texts.Any(t => t.Contains("{{", StringComparison.Ordinal)))
            throw new InvalidDataException($"{path}: 存在未展开占位符。");
        var workbook = Read(zip.GetEntry("xl/workbook.xml")!);
        if (workbook.Descendants(ns + "sheet").Count() != 5)
            throw new InvalidDataException($"{path}: 动态工作表数量不正确。");
        if (!zip.Entries.Any(e => e.FullName.StartsWith("xl/media/")))
            throw new InvalidDataException($"{path}: 图片未生成。");
        if (!zip.Entries.Any(e => e.FullName.StartsWith("xl/charts/chart") && e.FullName.EndsWith(".xml")))
            throw new InvalidDataException($"{path}: 图表未生成。");
    }
}
