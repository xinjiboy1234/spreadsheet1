# 本机队列与并发验证记录

日期：2026-11-01。环境：Windows、.NET 10、本机桌面 Excel。模板来自 TemplateFactory，包含基础字段、纵向循环、条件块、横向循环、动态 Sheet、图片、艺术字、图表。所有报告使用独立 Worker 和不同输出路径，共享同一只读模板。

| 检查 | 实测结果 |
| --- | --- |
| 单槽串行 | 6/6 成功，启动顺序一致，峰值1，11.4秒 |
| 双槽并发 | 6/6 成功，峰值2，8.1秒 |
| 错误恢复 | 1个错误模板按预期失败，另2个任务成功 |
| 取消与超时 | 排队取消、执行取消、20ms超时均按预期处理，前后2个正常任务成功 |
| 四槽并发 | 12/12 成功，峰值4，15.6秒 |
| 新增 Excel 进程残留 | 两轮完整检查均为0 |
| 输出目录暂存文件残留 | 两轮完整检查均为0 |
| 无 Office 队列逻辑检查 | 6/6通过 |
| 解决方案构建 | 0错误、0警告 |

并发报告逐个打开 ZIP/XML 结构检查对应任务数据、未展开占位符、动态 Sheet 数量、图片和图表部件。检查保留生成工作簿，可用 Excel 人工查看；这些断言不等同于对所有单元格样式和图表视觉结果的完整比对。

第一轮取消测试复现了启动时 Excel 残留：父进程在 Excel COM 激活返回且身份记录写入前杀掉 Worker。修复为先发取消信号、等待身份登记或 Worker 自行退出，再按 PID/启动时间清理；身份记录采用原子发布。针对取消场景单独重跑通过，随后完整四场景与四槽批次通过。长期 COM 激活卡死且无法提供身份的边界见 README。

重跑命令：

```powershell
dotnet build FillBee.slnx
dotnet run --project tests/FillBee.QueueChecks
dotnet run --project samples/FillBee.QueueSample -- all
dotnet run --project samples/FillBee.QueueSample -- parallel samples/FillBee.QueueSample/artifacts 12 4
```

工作负载与 Office 环境会影响耗时；以上记录为本次实际结果。
