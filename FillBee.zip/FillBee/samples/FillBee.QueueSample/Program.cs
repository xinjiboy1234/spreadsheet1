using System.Diagnostics;
using System.Text.Json;
using FillBee;
using FillBee.Sample;
using FillBee.QueueSample;

if (args.Contains("--help"))
{
    Console.WriteLine("用法：dotnet run --project samples/FillBee.QueueSample -- [all|serial|parallel|recovery|cancel] [输出目录] [任务数，默认6] [并发槽，默认2]");
    return;
}
if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException("需要 Windows 和桌面 Excel。");
var mode = args.ElementAtOrDefault(0) ?? "all";
if (!new[] { "all", "serial", "parallel", "recovery", "cancel" }.Contains(mode))
    throw new ArgumentException("未知模式，使用 --help 查看。");
var count = args.Length > 2 ? int.Parse(args[2]) : 6;
if (count < 2 || count > 200) throw new ArgumentOutOfRangeException(nameof(count), "任务数范围为2到200。");
var slots = args.Length > 3 ? int.Parse(args[3]) : 2;
if (slots < 1 || slots > 8 || slots > count) throw new ArgumentOutOfRangeException(nameof(slots), "并发槽范围1到8，且不能超过任务数。");
var root = Path.GetFullPath(args.ElementAtOrDefault(1) ?? Path.Combine(AppContext.BaseDirectory, "artifacts"));
var folder = Path.Combine(root, DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N")[..6]);
Directory.CreateDirectory(folder);
var baseline = ExcelProcesses();
var template = Path.Combine(folder, "template.xlsx");
var logo = Path.Combine(folder, "logo.bmp");
var image = new byte[54 + 16 * 16 * 3];
image[0] = (byte)'B'; image[1] = (byte)'M'; BitConverter.GetBytes(image.Length).CopyTo(image, 2);
image[10] = 54; image[14] = 40; image[18] = 16; image[22] = 16; image[26] = 1; image[28] = 24;
for (int i = 54; i < image.Length; i += 3) { image[i] = 210; image[i + 1] = 110; image[i + 2] = 35; }
await File.WriteAllBytesAsync(logo, image);
Console.WriteLine($"输出目录：{folder}");
Console.WriteLine("使用 Excel 创建一次模板；各任务只读共享模板，使用独立输出文件。");
await TemplateFactory.CreateAsync(template);
using var stop = new CancellationTokenSource();
Console.CancelKeyPress += (_, e) => { e.Cancel = true; stop.Cancel(); };
var summaries = new List<object>();

RenderJob Job(string id, TimeSpan? timeout = null, bool invalid = false)
{
    var data = SampleData.Create(logo) with { CompanyName = $"任务-{id}" };
    return new(invalid ? Path.Combine(folder, "missing-template.xlsx") : template,
        Path.Combine(folder, id + ".xlsx"), data,
        new RenderOptions(Timeout: timeout ?? TimeSpan.FromMinutes(2),
            SheetRepeats: [new SheetRepeat("DepartmentTemplate", "Departments")]));
}

async Task Batch(string label, int concurrency)
{
    Console.WriteLine($"\n=== {label}：{count} 个并发提交，执行槽 {concurrency}，等待容量 2 ===");
    var observer = new ObservedExecutor();
    var timer = Stopwatch.StartNew();
    await using (var queue = new RenderQueue(observer, capacity: 2, maxConcurrency: concurrency))
    {
        var tasks = Enumerable.Range(1, count).Select(async n =>
        {
            string id = $"{label}-{n:D2}";
            Console.WriteLine($"提交 {id}");
            var result = await queue.EnqueueAsync(Job(id), stop.Token);
            ReportCheck.Verify(result.OutputPath!, $"任务-{id}");
        }).ToArray();
        await Task.WhenAll(tasks);
    }
    if (observer.Peak != concurrency) throw new Exception($"期望峰值并发 {concurrency}，实际 {observer.Peak}。");
    if (concurrency == 1 && !observer.StartOrder.SequenceEqual(Enumerable.Range(1, count).Select(n => $"{label}-{n:D2}")))
        throw new Exception("串行队列未按入队顺序启动。");
    Console.WriteLine($"PASS {label}：成功 {count}/{count}，峰值并发 {observer.Peak}，耗时 {timer.Elapsed.TotalSeconds:F1}s。");
    summaries.Add(new { scenario = label, success = count, peak = observer.Peak, seconds = timer.Elapsed.TotalSeconds });
}

async Task Recovery()
{
    Console.WriteLine("\n=== recovery：失败任务与正常任务一起提交，错误不影响后续任务 ===");
    var observer = new ObservedExecutor();
    await using var queue = new RenderQueue(observer, capacity: 2, maxConcurrency: 2);
    var bad = queue.EnqueueAsync(Job("recovery-bad", invalid: true), stop.Token);
    var good = queue.EnqueueAsync(Job("recovery-good"), stop.Token);
    try { await bad; throw new Exception("错误模板意外成功。"); }
    catch (InvalidOperationException ex) when (ex.Message.Contains("Template file not found"))
    { Console.WriteLine("预期失败：模板不存在，异常已由调用方处理。"); }
    var result = await good;
    ReportCheck.Verify(result.OutputPath!, "任务-recovery-good");
    var next = await queue.EnqueueAsync(Job("recovery-next"), stop.Token);
    ReportCheck.Verify(next.OutputPath!, "任务-recovery-next");
    if (File.Exists(Job("recovery-bad").OutputPath)) throw new Exception("失败任务留下输出。");
    Console.WriteLine("PASS recovery：预期错误被隔离，另两个报告成功。");
    summaries.Add(new { scenario = "recovery", success = 2, expectedFailures = 1 });
}

async Task Cancellation()
{
    Console.WriteLine("\n=== cancel：取消等待任务、取消执行任务、超时后继续使用队列 ===");
    var observer = new ObservedExecutor();
    await using var queue = new RenderQueue(observer, capacity: 4);
    var first = queue.EnqueueAsync(Job("cancel-first"), stop.Token);
    await observer.FirstStarted.Task;
    using var waitingCts = CancellationTokenSource.CreateLinkedTokenSource(stop.Token);
    var waiting = queue.EnqueueAsync(Job("cancel-waiting"), waitingCts.Token);
    waitingCts.Cancel();
    try { await waiting; throw new Exception("等待任务未取消。"); }
    catch (OperationCanceledException) when (waitingCts.IsCancellationRequested) { Console.WriteLine("等待中的任务已取消。"); }
    var firstResult = await first;
    ReportCheck.Verify(firstResult.OutputPath!, "任务-cancel-first");
    using var activeCts = CancellationTokenSource.CreateLinkedTokenSource(stop.Token);
    activeCts.CancelAfter(TimeSpan.FromMilliseconds(500));
    try { await queue.EnqueueAsync(Job("cancel-active"), activeCts.Token); throw new Exception("执行任务未取消。"); }
    catch (OperationCanceledException) when (activeCts.IsCancellationRequested) { Console.WriteLine("已请求取消执行中的任务；执行槽等待 Worker 清理完成后继续。"); }
    try { await queue.EnqueueAsync(Job("cancel-timeout", TimeSpan.FromMilliseconds(20)), stop.Token); throw new Exception("超时任务意外成功。"); }
    catch (TimeoutException) { Console.WriteLine("超时任务已终止。"); }
    var result = await queue.EnqueueAsync(Job("cancel-after"), stop.Token);
    ReportCheck.Verify(result.OutputPath!, "任务-cancel-after");
    foreach (var id in new[] { "cancel-waiting", "cancel-active", "cancel-timeout" })
        if (File.Exists(Job(id).OutputPath)) throw new Exception($"{id} 留下了成功输出。");
    if (observer.StartOrder.Contains("cancel-waiting")) throw new Exception("取消的等待任务仍启动了执行器。");
    Console.WriteLine("PASS cancel：3个预期取消/超时，前后两个正常任务成功，未发布取消任务的输出。");
    summaries.Add(new { scenario = "cancel", success = 2, expectedCanceledOrTimeout = 3 });
}

if (mode is "all" or "serial") await Batch("serial", 1);
if (mode is "all" or "parallel") await Batch("parallel", slots);
if (mode is "all" or "recovery") await Recovery();
if (mode is "all" or "cancel") await Cancellation();
// Only observe process identities; never terminate unrelated Excel instances in the sample.
HashSet<string> added = [];
for (int i = 0; i < 20; i++)
{
    added = ExcelProcesses().Except(baseline).ToHashSet();
    if (added.Count == 0) break;
    await Task.Delay(500, stop.Token);
}
if (added.Count != 0) throw new Exception("检测到本轮期间新增且仍存活的 Excel 实例，请检查：" + string.Join(", ", added));
var missingOriginal = baseline.Except(ExcelProcesses()).ToArray();
if (missingOriginal.Length > 0) Console.WriteLine("提示：运行前的 Excel 进程在运行期间退出：" + string.Join(", ", missingOriginal));
var staging = Directory.GetFiles(folder, ".fillbee-*", SearchOption.AllDirectories);
if (staging.Length != 0) throw new Exception("暂存文件未清理：" + string.Join(",", staging));
var summary = Path.Combine(folder, "summary.json");
await File.WriteAllTextAsync(summary, JsonSerializer.Serialize(new { passed = true, scenarios = summaries, addedExcelProcessesRemaining = added.Count, temporaryFilesRemaining = staging.Length }, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"\n全部所选场景通过，新增 Excel 进程残留 0，暂存文件残留 0。结果：{summary}");

static HashSet<string> ExcelProcesses()
{
    var result = new HashSet<string>();
    foreach (var process in Process.GetProcessesByName("EXCEL"))
    {
        using (process) try { result.Add($"{process.Id}:{process.StartTime.ToUniversalTime().Ticks}"); }
        catch (InvalidOperationException) { }
    }
    return result;
}

