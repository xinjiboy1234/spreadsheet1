using FillBee;
namespace FillBee.Sample;

public sealed record Product(string Name, int Quantity, decimal Price);
public sealed record Department(string Name, Product[] Items);
public sealed record ReportData(string CompanyName, string CreatedAt, bool ShowNote,
    Product[] Items, Department[] Departments, ImageValue Logo, WordArtValue Title, ChartValue Sales);

internal static class SampleData
{
    public static ReportData Create(string imagePath) => new(
        "华星科技", DateTime.Today.ToString("yyyy-MM-dd"), true,
        [new("产品 A", 2, 120.50m), new("产品 B", 5, 89m), new("产品 C", 1, 350m)],
        [new("华东区", [new("设备 A", 3, 200m)]), new("华南区", [new("设备 B", 2, 450m)])],
        ImageValue.FromFile(imagePath), new("销售报告"), new("产品数量", "A2:B4"));
}
