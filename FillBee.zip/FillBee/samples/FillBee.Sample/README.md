# FillBee 调用示例

需要 Windows、.NET 10 SDK，以及已安装并注册的 Microsoft Excel。

从解决方案目录运行：

```powershell
dotnet run --project samples/FillBee.Sample
```

指定输出目录：

```powershell
dotnet run --project samples/FillBee.Sample -- "D:\Reports\FillBeeDemo"
```

默认生成到示例程序目录下的 `artifacts`，每次使用唯一文件名，包含模板、报告和示例 BMP 图片。按 Ctrl+C 可取消渲染。查看参数：`dotnet run --project samples/FillBee.Sample -- --help`。

- `Program.cs`：完整调用链：生成模板、Validate、准备模型、配置 SheetRepeat、RenderAsync、显示输出。
- `SampleData.cs`：强类型模型，含产品、部门、ImageValue、WordArtValue、ChartValue。
- `TemplateFactory.cs`：在 STA 线程内通过 Excel COM 创建模板，并释放示例自己创建的 COM 对象。

模板含四张表：

- 销售报表：对象属性、数字格式化、纵向循环、布尔条件块。
- 横向产品：按产品集合复制模板列。
- DepartmentTemplate：按 Departments 复制为华东区、华南区，各自绑定当前项与根对象，并填充产品明细。
- 图片艺术字图表：按形状名称绑定 Logo、Title、Sales，保留原有对象格式。

日期由示例模型预格式化成字符串，以避免跨进程 JSON 传输时日期类型转换影响演示。图表采用固定示例数据区域 A2:B4。

默认启用独立 Worker；项目构建目标会把 FillBee.runtimeconfig.json 和 FillBee.deps.json 复制到输出目录。部署示例时复制整个输出目录。

完整调用的关键代码：

```csharp
var renderer = new ExcelTemplateRenderer();
var options = new RenderOptions(
    Timeout: TimeSpan.FromMinutes(2),
    SheetRepeats: [new SheetRepeat("DepartmentTemplate", "Departments")]);
var result = await renderer.RenderAsync(template, output, model, options, cancellationToken);
```

模板设计人员请阅读 [模板设计说明书](../../docs/template-design-guide.md)。

批量排队和并发调用请参考 [队列与并发示例](../FillBee.QueueSample/README.md)。
