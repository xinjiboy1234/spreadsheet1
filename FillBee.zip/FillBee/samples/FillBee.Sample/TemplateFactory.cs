using System.Runtime.InteropServices;
namespace FillBee.Sample;

internal sealed class ComScope : IDisposable
{
    private readonly List<object> _references = [];
    public dynamic Keep(object value) { _references.Add(value); return value; }
    public void Dispose()
    {
        for (int i = _references.Count - 1; i >= 0; i--)
            if (Marshal.IsComObject(_references[i])) Marshal.ReleaseComObject(_references[i]);
    }
}

internal static class TemplateFactory
{
    public static Task CreateAsync(string path)
    {
        var completion = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var thread = new Thread(() =>
        {
            try { Create(path); completion.SetResult(); }
            catch (Exception ex) { completion.SetException(ex); }
        });
        thread.SetApartmentState(ApartmentState.STA);
        thread.Start();
        return completion.Task;
    }

    private static void Create(string path)
    {
        using var com = new ComScope();
        dynamic app = com.Keep(Activator.CreateInstance(Type.GetTypeFromProgID("Excel.Application")
            ?? throw new InvalidOperationException("请安装并注册 Microsoft Excel。"))!);
        object? workbook = null;
        try
        {
            app.Visible = false;
            app.DisplayAlerts = false;
            app.AutomationSecurity = 3;
            dynamic books = com.Keep(app.Workbooks);
            dynamic book = com.Keep(books.Add());
            workbook = book;
            dynamic sheets = com.Keep(book.Worksheets);
            while ((int)sheets.Count > 1) { dynamic extra = com.Keep(sheets.Item((int)sheets.Count)); extra.Delete(); }
            dynamic summary = com.Keep(sheets.Item(1));
            summary.Name = "销售报表";
            Set(com, summary, 1, 1, "{{CompanyName}} 销售报表");
            Set(com, summary, 2, 1, "报告日期：{{CreatedAt}}");
            Set(com, summary, 4, 1, "产品"); Set(com, summary, 4, 2, "数量"); Set(com, summary, 4, 3, "单价");
            Set(com, summary, 5, 1, "{{#each Items}}");
            Set(com, summary, 6, 1, "{{Name}}"); Set(com, summary, 6, 2, "{{Quantity}}");
            Set(com, summary, 6, 3, "{{Price | number:\"#,##0.00\"}}");
            Set(com, summary, 7, 1, "{{/each}}");
            Set(com, summary, 9, 1, "{{#if ShowNote}}"); Set(com, summary, 10, 1, "说明：这是 FillBee 自动生成的示例。"); Set(com, summary, 11, 1, "{{/if}}");

            dynamic horizontal = Add(com, sheets, "横向产品");
            Set(com, horizontal, 1, 1, "{{#each Items direction=\"right\"}}");
            Set(com, horizontal, 1, 2, "{{Name}}"); Set(com, horizontal, 2, 2, "数量：{{Quantity}}");
            Set(com, horizontal, 1, 3, "{{/each}}");

            dynamic detail = Add(com, sheets, "DepartmentTemplate");
            Set(com, detail, 1, 1, "{{@root.CompanyName}} / {{Name}}");
            Set(com, detail, 3, 1, "{{#each Items}}");
            Set(com, detail, 4, 1, "{{@index}}. {{Name}}，数量：{{Quantity}}");
            Set(com, detail, 5, 1, "{{/each}}");

            dynamic objects = Add(com, sheets, "图片艺术字图表");
            Set(com, objects, 1, 1, "产品"); Set(com, objects, 1, 2, "数量");
            Set(com, objects, 2, 1, "产品 A"); Set(com, objects, 2, 2, 2);
            Set(com, objects, 3, 1, "产品 B"); Set(com, objects, 3, 2, 5);
            Set(com, objects, 4, 1, "产品 C"); Set(com, objects, 4, 2, 1);
            dynamic shapes = com.Keep(objects.Shapes);
            dynamic logo = com.Keep(shapes.AddShape(1, 250, 10, 100, 65)); logo.Name = "tpl:image:Logo";
            dynamic title = com.Keep(shapes.AddTextEffect(0, "模板标题", "Arial", 24, 0, 0, 380, 15)); title.Name = "tpl:wordart:Title";
            dynamic charts = com.Keep(objects.ChartObjects());
            dynamic chart = com.Keep(charts.Add(230, 110, 460, 260)); chart.Name = "tpl:chart:Sales";
            dynamic chartContent = com.Keep(chart.Chart); chartContent.ChartType = 51;

            for (int i = 1; i <= (int)sheets.Count; i++)
            {
                dynamic sheet = com.Keep(sheets.Item(i));
                dynamic used = com.Keep(sheet.UsedRange);
                dynamic columns = com.Keep(used.Columns); columns.ColumnWidth = 28;
                dynamic font = com.Keep(used.Font); font.Name = "Microsoft YaHei"; font.Size = 11;
            }
            book.SaveAs(path, 51);
        }
        finally
        {
            try { if (workbook is not null) ((dynamic)workbook).Close(false); }
            finally { app.Quit(); }
        }
    }

    private static dynamic Add(ComScope com, dynamic sheets, string name)
    {
        dynamic last = com.Keep(sheets.Item((int)sheets.Count));
        dynamic sheet = com.Keep(sheets.Add(Type.Missing, last)); sheet.Name = name; return sheet;
    }

    private static void Set(ComScope com, dynamic sheet, int row, int column, object value)
    {
        dynamic cells = com.Keep(sheet.Cells);
        dynamic cell = com.Keep(cells[row, column]); cell.Value2 = value;
    }
}
