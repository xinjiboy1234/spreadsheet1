using FillBee;
using FillBee.Sample;

if (args.Contains("--help"))
{
    Console.WriteLine("用法：dotnet run --project samples/FillBee.Sample -- [输出目录]");
    return;
}
if (!OperatingSystem.IsWindows()) throw new PlatformNotSupportedException("本示例需要 Windows 和桌面 Microsoft Excel。");
var folder = Path.GetFullPath(args.FirstOrDefault() ?? Path.Combine(AppContext.BaseDirectory, "artifacts"));
Directory.CreateDirectory(folder);
// Unique file names allow repeated runs without overwriting an existing template/report.
var runId = DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N")[..6];
//var template = Path.Combine(folder, $"template-{runId}.xlsx");
var template = Path.Combine(folder, $"template-20261101-184449-922019.xlsx");
var output = Path.Combine(folder, $"report-{runId}.xlsx");
var logo = Path.Combine(folder, $"logo-{runId}.bmp");
// A small blue BMP keeps the example independent of downloaded assets or image packages.
var image = new byte[54 + 16 * 16 * 3];
image[0] = (byte)'B'; image[1] = (byte)'M';
BitConverter.GetBytes(image.Length).CopyTo(image, 2); image[10] = 54; image[14] = 40;
image[18] = 16; image[22] = 16; image[26] = 1; image[28] = 24;
for (int i = 54; i < image.Length; i += 3) { image[i] = 210; image[i + 1] = 110; image[i + 2] = 35; }
await File.WriteAllBytesAsync(logo, image);

using var stop = new CancellationTokenSource();
Console.CancelKeyPress += (_, e) => { e.Cancel = true; stop.Cancel(); };
Console.WriteLine("正在使用 Excel 创建示例模板……");
//await TemplateFactory.CreateAsync(template);
var renderer = new ExcelTemplateRenderer();
var validation = renderer.Validate(template);
foreach (var diagnostic in validation.Diagnostics)
    Console.WriteLine($"{diagnostic.Code} {diagnostic.SheetName}!{diagnostic.CellAddress}: {diagnostic.Message}");
if (!validation.IsValid) throw new InvalidDataException("示例模板未通过验证。");

var model = SampleData.Create(logo);
var options = new RenderOptions(
    Timeout: TimeSpan.FromMinutes(2),
    SheetRepeats: [new SheetRepeat("DepartmentTemplate", "Departments")]);
Console.WriteLine("正在启动独立 Worker 生成报告……");
var result = await renderer.RenderAsync(template, output, model, options, stop.Token);
Console.WriteLine($"生成成功，耗时 {result.Duration.TotalSeconds:F1} 秒");
Console.WriteLine($"模板：{template}");
Console.WriteLine($"报告：{result.OutputPath}");
