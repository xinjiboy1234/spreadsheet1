# FillBee 使用说明

需要 Windows、.NET 10 和已注册的桌面 Excel。默认每次 RenderAsync 启动独立 dotnet Worker；部署时应保留 FillBee.dll、FillBee.deps.json、FillBee.runtimeconfig.json。不要只复制 DLL。

```csharp
var renderer = new ExcelTemplateRenderer();
var result = await renderer.RenderAsync("template.xlsx", "report.xlsx", model,
    new RenderOptions(Timeout: TimeSpan.FromMinutes(3),
        SheetRepeats: new[] { new SheetRepeat("DetailTemplate", "Departments") }), cancellationToken);
```

纵向循环的起止标记分别独占一行：`{{#each Items}}`、模板内容行、`{{/each}}`。支持多行循环体及纵向嵌套。条件块使用 `{{#if Enabled}}` 和 `{{/if}}`，Enabled 为 bool。循环内支持 @index、@count、@parent.Name、@root.Name。

横向循环的起止标记分别独占一列并位于同一行：`{{#each Months direction="right"}}`、模板列、`{{/each}}`。引擎复制完整列；横纵循环交叉区域不在当前验证覆盖范围内。

动态工作表通过 SheetRepeats 配置，模板 Sheet 会按集合复制并删除。名称自动处理非法字符、31 字符上限和重名。每张生成表使用当前集合项作为上下文。

形状命名：tpl:image:Logo、tpl:wordart:Title、tpl:chart:Sales。分别绑定 ImageValue、WordArtValue、ChartValue。图片支持 Contain、Cover、Stretch；图表通过 SourceRange 指定当前 Sheet 的数据区域。现有图表样式保留。

格式示例：`{{Amount | number:"#,##0.00"}}`、`{{CreatedAt | date:"yyyy-MM-dd"}}`。通过 renderer.Formatters.Register 注册格式器时，应使用 UseWorker=false；自定义实例不能跨进程序列化。该模式不提供强制终止能力。

默认 Worker 超时三分钟。取消或超时终止 Worker 并按 PID 与启动时间核对后清理其 Excel 实例。源模板与输出必须不同，失败不会发布暂存文件。默认禁用宏和 Excel 事件，外部链接不更新。

运行本机 Excel 集成检查：`dotnet run --project tests/Smoke/Smoke.csproj`。此检查会创建独立 Excel 实例与临时工作簿，覆盖基本填充、纵向循环、横向循环、条件、动态 Sheet、公式保留及默认 Worker 调用。

当前限制：循环中的浮动 Shape 尚无专门复制映射；合并跨界、复杂公式/图表引用、保护状态与数据模型路径尚没有完整预检；自定义绑定器与条件判断器尚未提供；当前不承诺横纵交叉嵌套及 P2 对象的主动修改。Validate 返回的是语法与文件结构检查结果，不表示全部兼容性已验证。

完整可运行示例见 samples/FillBee.Sample/README.md。运行：dotnet run --project samples/FillBee.Sample。

模板制作步骤与语法详见 [模板设计说明书](template-design-guide.md)。

队列与并发运行示例见 [FillBee.QueueSample](../samples/FillBee.QueueSample/README.md)，包含串行队列、受控并发、错误恢复、取消与超时。
