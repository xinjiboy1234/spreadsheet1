# Excel Template Engine Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver the full Excel template rendering feature set described in `requirement.md` through a reusable .NET API backed by Excel COM.

**Architecture:** Separate template syntax/data binding/validation from Excel COM execution. Use a dedicated STA worker process for rendering, planning worksheet mutations before applying them, then bind cell values and supported shapes. Preserve original workbooks through temporary output and atomic replacement.

**Tech Stack:** C#/.NET 10, late-bound Excel COM, XML/ZIP inspection, xUnit unit tests, Windows Excel integration tests.

**Spec:** `requirement.md`

## Global Constraints

- Never overwrite the source template; save to a temporary output and replace only after success.
- Do not evaluate arbitrary expressions or run template macros; disable external link updates by default.
- Excel COM calls stay on a dedicated STA thread in an isolated worker process.
- Preserve Excel-native formatting and unsupported objects where possible; report unsupported mutations diagnostically.
- Keep public API compatible with `IExcelTemplateRenderer`, adding overloads instead of breaking existing callers.

## Review Focus

- Missing/null nested members and dictionaries must follow configured policy; test path resolution and diagnostics.
- Empty collections and nested loops must not corrupt row/column offsets; test zero/one/many and nested data.
- Malformed, overlapping, or cross-merge directives must fail validation with location; test parser diagnostics.
- Cancellation/timeouts must terminate only the owned worker and never publish partial output; test worker lifecycle.
- Shape/image/chart and formula behavior varies by Excel version; test adapters with fakes and keep real Office tests gated.

---

### Task 1: Public model and safe data binding
**Files:** `ExcelTemplateEngine/RenderQueue.cs`, create `TemplateData.cs`, `TemplateFormatting.cs`; tests project.
- [ ] Add public render options, image value, formatter/binder contracts, typed exceptions and diagnostic codes without breaking existing constructors.
- [ ] Implement case-insensitive POCO/dictionary path resolution, root/parent/current scope and index/count metadata.
- [ ] Implement registered number/date/default formatters and escaped literal tokens.
- [ ] Verify scalar/path/format behavior with unit tests.

### Task 2: Template parser and validator
**Files:** create `TemplateSyntax.cs`, `TemplateValidator.cs`; modify `TemplateRenderer.cs`; tests.
- [ ] Parse variable, each (vertical/right), if, image/wordart/chart shape declarations into source-located nodes.
- [ ] Validate balanced blocks, nesting, region overlap, merge boundaries, shape names and optional model type paths.
- [ ] Return actionable `TemplateDiagnostic` entries with sheet/cell/shape locations.
- [ ] Verify malformed, nested, and valid templates using generated minimal xlsx fixtures.

### Task 3: Excel mutation planning and worksheet rendering
**Files:** create `RenderPlanner.cs`, `ExcelWorkbookRenderer.cs`; modify `TemplateRenderer.cs`; tests.
- [ ] Build immutable render operations against original coordinates before mutation.
- [ ] Implement scalar replacement and vertical multi-row loops using Excel row copy/insert; remove markers and honor empty collection behavior.
- [ ] Implement nested loops, horizontal expansion, conditions, formulas, and merge-aware region handling.
- [ ] Verify planner offsets and expected cell matrices with fake workbook adapter tests.

### Task 4: Dynamic sheets and native objects
**Files:** create `ExcelShapeBinder.cs`, `SheetTemplateExpander.cs`; tests.
- [ ] Expand configured repeated sheets, generate legal unique 31-character names, bind current/root contexts.
- [ ] Bind image values into named placeholder shapes with fit/crop/position modes; update WordArt text preserving formatting.
- [ ] Update chart titles/data bindings where supported and diagnose unsupported chart/object types.
- [ ] Verify binding logic via adapter tests and gated Excel integration cases.

### Task 5: Isolated worker and render queue
**Files:** create `ExcelTemplate.Worker` project and worker protocol; modify `RenderQueue.cs`, `TemplateRenderer.cs`, solution.
- [ ] Move COM automation to dedicated STA worker executable; serialize model/options through a safe request protocol.
- [ ] Enforce per-job timeout/cancellation by terminating only the spawned worker; clean temporary files and owned Excel process.
- [ ] Fix queue cancellation propagation, shutdown draining, timeout behavior, and atomic output publication.
- [ ] Verify worker protocol and queue behavior without Office; run Windows Excel process integration tests when Office exists.

### Task 6: Samples, docs, and acceptance verification
**Files:** create `samples/`, `docs/`; tests and project configuration.
- [ ] Add form/list/nested/image/WordArt/multi-sheet sample models and template authoring guide.
- [ ] Add template checker usage, support matrix, deployment/COM process guidance and explicit limitations.
- [ ] Run build and unit tests; run integration tests only when Excel is installed and report the distinction.

## Coverage review

The tasks cover P0/P1 features in requirement.md: scalar/form fill, object paths/dictionaries, vertical/horizontal/nested loops, dynamic sheets, images, WordArt, charts, conditions, validation, formatting, COM isolation, timeout/cancellation, and samples/docs. P2 SmartArt/OLE remains pass-through when untouched and produces diagnostics when a requested mutation is unsupported, matching the compatibility boundary in the spec.
