using FillBee;

var checks = new (string Name, Func<Task> Run)[]
{
    ("并发槽上限与所有任务完成", Concurrency),
    ("单槽启动顺序", Fifo),
    ("队列容量背压与排队取消", Backpressure),
    ("失败任务后继续执行", Recovery),
    ("超时参数与超时后恢复", Timeouts),
    ("释放时排空并且只释放执行器一次", Drain)
};
foreach (var check in checks)
{
    await check.Run().WaitAsync(TimeSpan.FromSeconds(10));
    Console.WriteLine("PASS " + check.Name);
}
Console.WriteLine($"{checks.Length}/{checks.Length} 队列检查通过，无需 Excel。");

static RenderJob Job(string id, RenderOptions? options = null) => new("template.xlsx", id, new { Name = id }, options);
static void Require(bool condition, string message) { if (!condition) throw new Exception(message); }
static async Task Expect<T>(Task task) where T : Exception
{
    try { await task; }
    catch (T) { return; }
    throw new Exception($"Expected {typeof(T).Name}.");
}
static RenderResult Result(RenderJob job) => new(true, job.OutputPath, TimeSpan.Zero, []);

static async Task Concurrency()
{
    var started = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    var release = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    int active = 0, peak = 0, total = 0;
    var executor = new FakeExecutor(async (job, ct) =>
    {
        var current = Interlocked.Increment(ref active);
        int old;
        do { old = peak; } while (current > old && Interlocked.CompareExchange(ref peak, current, old) != old);
        if (Interlocked.Increment(ref total) == 2) started.TrySetResult();
        try { await release.Task.WaitAsync(ct); return Result(job); }
        finally { Interlocked.Decrement(ref active); }
    });
    await using var queue = new RenderQueue(executor, capacity: 2, maxConcurrency: 2);
    var tasks = Enumerable.Range(1, 12).Select(i => queue.EnqueueAsync(Job(i.ToString()))).ToArray();
    await started.Task;
    Require(active == 2, "Two jobs must run together.");
    release.SetResult();
    await Task.WhenAll(tasks);
    Require(total == 12 && peak == 2, "Concurrency limit or task count was violated.");
}

static async Task Fifo()
{
    var starts = new List<string>();
    await using var queue = new RenderQueue(new FakeExecutor(async (job, ct) =>
    {
        starts.Add(job.OutputPath); await Task.Delay(5, ct); return Result(job);
    }), capacity: 1);
    await Task.WhenAll(Enumerable.Range(0, 6).Select(i => queue.EnqueueAsync(Job(i.ToString()))));
    Require(starts.SequenceEqual(Enumerable.Range(0, 6).Select(i => i.ToString())), "Serial start order changed.");
}

static async Task Backpressure()
{
    var entered = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    var release = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
    var starts = new List<string>();
    await using var queue = new RenderQueue(new FakeExecutor(async (job, ct) =>
    {
        starts.Add(job.OutputPath); entered.TrySetResult(); await release.Task.WaitAsync(ct); return Result(job);
    }), capacity: 1);
    var first = queue.EnqueueAsync(Job("first"));
    await entered.Task;
    using var queuedCancellation = new CancellationTokenSource();
    using var producerCancellation = new CancellationTokenSource();
    var second = queue.EnqueueAsync(Job("queued"), queuedCancellation.Token);
    var third = queue.EnqueueAsync(Job("blocked-producer"), producerCancellation.Token);
    Require(!third.IsCompleted, "Full channel must apply backpressure.");
    producerCancellation.Cancel(); queuedCancellation.Cancel();
    await Expect<OperationCanceledException>(third);
    await Expect<OperationCanceledException>(second);
    release.SetResult(); await first;
    await queue.EnqueueAsync(Job("after"));
    Require(starts.SequenceEqual(new[] { "first", "after" }), "Canceled work reached the executor.");
}

static async Task Recovery()
{
    await using var queue = new RenderQueue(new FakeExecutor((job, _) =>
        job.OutputPath == "bad" ? Task.FromException<RenderResult>(new InvalidDataException("bad input")) : Task.FromResult(Result(job))));
    var bad = queue.EnqueueAsync(Job("bad"));
    var good = queue.EnqueueAsync(Job("good"));
    await Expect<InvalidDataException>(bad);
    Require((await good).Success, "Failure stopped the queue.");
}

static async Task Timeouts()
{
    await using var queue = new RenderQueue(new FakeExecutor(async (job, ct) =>
    {
        if (job.OutputPath == "slow") await Task.Delay(Timeout.InfiniteTimeSpan, ct);
        return Result(job);
    }));
    await Expect<ArgumentOutOfRangeException>(queue.EnqueueAsync(Job("invalid", new RenderOptions(Timeout: TimeSpan.FromMilliseconds(-5)))));
    await Expect<TimeoutException>(queue.EnqueueAsync(Job("slow", new RenderOptions(Timeout: TimeSpan.FromMilliseconds(30)))));
    Require((await queue.EnqueueAsync(Job("after"))).Success, "Timeout stopped the queue.");
}

static async Task Drain()
{
    int completed = 0;
    var executor = new FakeExecutor(async (job, ct) =>
    {
        await Task.Delay(10, ct); Interlocked.Increment(ref completed); return Result(job);
    });
    var queue = new RenderQueue(executor, capacity: 8, maxConcurrency: 2);
    var jobs = Enumerable.Range(0, 6).Select(i => queue.EnqueueAsync(Job(i.ToString()))).ToArray();
    await Task.WhenAll(queue.DisposeAsync().AsTask(), queue.DisposeAsync().AsTask());
    await Task.WhenAll(jobs);
    Require(completed == 6 && executor.DisposeCount == 1, "Dispose did not drain jobs or disposed twice.");
    await Expect<ObjectDisposedException>(queue.EnqueueAsync(Job("late")));
}

sealed class FakeExecutor(Func<RenderJob, CancellationToken, Task<RenderResult>> callback) : IRenderExecutor
{
    public int DisposeCount;
    public Task<RenderResult> ExecuteAsync(RenderJob job, CancellationToken cancellationToken) => callback(job, cancellationToken);
    public ValueTask DisposeAsync() { Interlocked.Increment(ref DisposeCount); return ValueTask.CompletedTask; }
}
